# 🌤️ OpenWeatherMap API - Free Setup Guide

## 100% FREE - No Credit Card Required

OpenWeatherMap provides a generous free tier perfect for this project!

---

## 📋 Quick Setup (5 Minutes)

### Step 1: Create Free Account

1. **Go to OpenWeatherMap**
   - Visit: https://openweathermap.org/api
   - Click "Sign Up" button (top right)

2. **Fill Registration Form**
   - Username: Choose any username
   - Email: Your email address
   - Password: Create strong password
   - Age confirmation: Check the box
   - Privacy policy: Check the box
   - Click "Create Account"

3. **Verify Email**
   - Check your email inbox
   - Click verification link
   - Account is now active!

---

### Step 2: Get Your API Key

1. **Login to Your Account**
   - Go to: https://home.openweathermap.org/
   - Enter your credentials

2. **Navigate to API Keys**
   - Click your username (top right)
   - Select "My API keys"
   - Or go directly to: https://home.openweathermap.org/api_keys

3. **Copy Your Default API Key**
   - You'll see a default key already created
   - It looks like: `a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6`
   - Click the copy icon or select and copy

4. **Wait for Activation**
   - ⚠️ **IMPORTANT**: New API keys take 10 minutes to activate
   - Don't worry if it doesn't work immediately
   - Have a coffee break ☕

---

### Step 3: Add to Your Project

1. **Open Your Project**
   - Navigate to: `/workspace/app-7ohd5n562xhd/`

2. **Edit .env File**
   - Open `.env` in any text editor
   - Find this line:
     ```
     VITE_OPENWEATHER_API_KEY=your_openweathermap_api_key_here
     ```

3. **Replace with Your Key**
   - Replace `your_openweathermap_api_key_here` with your actual key
   - Example:
     ```
     VITE_OPENWEATHER_API_KEY=a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6
     ```

4. **Save the File**
   - Save and close

5. **Restart Your Application**
   - If running, stop and restart
   - The new key will be loaded

---

## 💰 Free Tier Details

### What You Get for FREE

✅ **1,000 API calls per day**  
✅ **60 calls per minute**  
✅ **Current weather data**  
✅ **5-day forecast**  
✅ **No credit card required**  
✅ **No automatic charges**  

### Is This Enough?

**For this project**: ✅ **YES, more than enough!**

**Usage calculation**:
- Auto-refresh every 5 minutes = 12 calls/hour
- 24 hours = 288 calls/day
- **You have 1,000 calls/day** = plenty of headroom!

**For development**: ✅ **Perfect!**

**For production**: ✅ **Good for small-medium traffic**

---

## 🧪 Testing Your API Key

### Method 1: Browser Test

1. **Open Browser**
2. **Paste this URL** (replace YOUR_API_KEY):
   ```
   https://api.openweathermap.org/data/2.5/weather?lat=35.6762&lon=139.6503&units=metric&appid=YOUR_API_KEY
   ```
3. **Check Response**
   - ✅ Success: You'll see JSON weather data
   - ❌ Error: Check if key is activated (wait 10 minutes)

### Method 2: Command Line Test

```bash
curl "https://api.openweathermap.org/data/2.5/weather?lat=35.6762&lon=139.6503&units=metric&appid=YOUR_API_KEY"
```

### Method 3: In Your Application

1. Open your application
2. Go to Home page
3. Open browser console (F12)
4. Look for weather API calls
5. Check for errors

---

## 🔍 What Data You'll Get

### Weather Information

```json
{
  "main": {
    "temp": 15.5,        // Temperature in Celsius
    "humidity": 65       // Humidity percentage
  },
  "wind": {
    "speed": 5.2         // Wind speed in m/s
  },
  "rain": {
    "1h": 2.5            // Rainfall in last hour (mm)
  },
  "weather": [
    {
      "description": "light rain"  // Weather description
    }
  ]
}
```

### Risk Level Calculation

Your app automatically calculates risk based on:

**Rainfall**:
- < 10mm: Low risk
- 10-25mm: Moderate risk
- 25-50mm: High risk
- > 50mm: Critical risk

**Wind Speed**:
- < 10 m/s: Low risk
- 10-15 m/s: Moderate risk
- 15-25 m/s: High risk
- > 25 m/s: Critical risk

---

## 🚨 Common Issues & Solutions

### Issue 1: "Invalid API key"

**Cause**: Key not activated yet

**Solution**:
- Wait 10 minutes after creating account
- Check if you copied the entire key
- No spaces before/after the key

### Issue 2: "401 Unauthorized"

**Cause**: Wrong API key or not activated

**Solution**:
1. Go to: https://home.openweathermap.org/api_keys
2. Verify your key is correct
3. Copy it again carefully
4. Update `.env` file
5. Restart application

### Issue 3: "429 Too Many Requests"

**Cause**: Exceeded free tier limits

**Solution**:
- Wait until next day (resets at midnight UTC)
- Increase refresh interval in code
- Consider upgrading plan (optional)

### Issue 4: No weather data showing

**Check**:
1. API key in `.env` is correct
2. Application restarted after adding key
3. Browser console for errors
4. Internet connection working

---

## 📊 Monitor Your Usage

### Check API Calls

1. **Login to OpenWeatherMap**
   - Go to: https://home.openweathermap.org/

2. **View Statistics**
   - Click "Statistics" in menu
   - See your daily usage
   - Monitor remaining calls

3. **Set Up Alerts** (Optional)
   - Get notified at 80% usage
   - Prevent hitting limits

---

## 🔒 Security Best Practices

### Protect Your API Key

✅ **DO**:
- Keep key in `.env` file
- Add `.env` to `.gitignore`
- Never commit to GitHub
- Use environment variables

❌ **DON'T**:
- Share your key publicly
- Commit to version control
- Hardcode in source files
- Post in forums/chat

### If Key is Compromised

1. Go to: https://home.openweathermap.org/api_keys
2. Click "Delete" on compromised key
3. Click "Generate" to create new key
4. Update `.env` with new key
5. Restart application

---

## 📈 Upgrade Options (Optional)

### If You Need More

**Startup Plan** ($40/month):
- 100,000 calls/day
- 600 calls/minute
- Historical data access
- More features

**Developer Plan** ($125/month):
- 1,000,000 calls/day
- 3,000 calls/minute
- All features

**For this project**: Free tier is sufficient! ✅

---

## 🎯 Integration in Your App

### Where It's Used

1. **Home Page**
   - Weather risk indicators
   - Real-time conditions

2. **Analytics Page**
   - Weather-based predictions
   - Risk assessment

3. **Alerts Page**
   - Weather-triggered alerts
   - Storm warnings

### How It Works

```typescript
// Fetch weather for a location
const weather = await fetchWeatherData(
  latitude,
  longitude,
  apiKey
);

// Returns:
{
  temperature: 15.5,
  rainfall: 2.5,
  windSpeed: 5.2,
  humidity: 65,
  description: "light rain",
  riskLevel: "moderate"  // Auto-calculated
}
```

---

## 🌍 Global Coverage

### Supported Locations

✅ **Worldwide coverage**  
✅ **200,000+ cities**  
✅ **Any coordinates**  
✅ **Real-time updates**  

### Data Accuracy

- **Update frequency**: Every 10 minutes
- **Data sources**: 40,000+ weather stations
- **Satellite data**: Yes
- **Forecast accuracy**: 85-90%

---

## 📞 Support & Help

### Official Resources

- **Documentation**: https://openweathermap.org/api
- **FAQ**: https://openweathermap.org/faq
- **Support**: https://openweathermap.org/support
- **Community**: https://openweathermap.org/community

### Quick Links

- **API Keys**: https://home.openweathermap.org/api_keys
- **Statistics**: https://home.openweathermap.org/statistics
- **Billing**: https://home.openweathermap.org/subscriptions

---

## ✅ Checklist

Before using the app, make sure:

- [ ] OpenWeatherMap account created
- [ ] Email verified
- [ ] API key copied
- [ ] API key added to `.env` file
- [ ] Waited 10 minutes for activation
- [ ] Application restarted
- [ ] Tested API key (browser or curl)
- [ ] No errors in browser console
- [ ] Weather data showing in app

---

## 🎉 You're All Set!

Your OpenWeatherMap API is now configured and ready to provide:

✅ **Real-time weather data**  
✅ **Rainfall measurements**  
✅ **Wind speed tracking**  
✅ **Automatic risk calculation**  
✅ **Global coverage**  
✅ **100% FREE** within generous limits  

**Remember**: The free tier gives you 1,000 calls/day - more than enough for this project!

---

**Last Updated**: November 2025  
**Status**: ✅ Verified Working  
**Cost**: 💰 FREE Forever (within limits)
