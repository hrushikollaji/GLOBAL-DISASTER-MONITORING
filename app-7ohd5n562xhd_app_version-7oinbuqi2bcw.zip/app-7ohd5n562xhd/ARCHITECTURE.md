# AI Disaster Alert Platform - Technical Architecture

## 📐 System Architecture

### Technology Stack

**Frontend Framework:**
- React 18 with TypeScript
- Vite for build tooling
- React Router for navigation

**UI Components:**
- shadcn/ui component library
- Radix UI primitives
- Tailwind CSS for styling
- Lucide React for icons

**Data Visualization:**
- Recharts for charts and graphs
- Google Maps JavaScript API for mapping

**State Management:**
- React Hooks (useState, useEffect)
- localStorage for persistence
- Context API ready for global state

**Form Handling:**
- React Hook Form
- Zod for validation

## 🗂️ Project Structure

```
src/
├── components/
│   ├── ui/                    # shadcn/ui components
│   ├── common/                # Shared components
│   │   ├── Header.tsx         # Navigation header
│   │   ├── Footer.tsx         # Site footer
│   │   └── PageMeta.tsx       # SEO metadata
│   └── disaster/              # Disaster-specific components
│       └── DisasterCard.tsx   # Disaster event card
│
├── pages/                     # Route pages
│   ├── Home.tsx              # Main dashboard with map
│   ├── Analytics.tsx         # Data visualization
│   ├── Alerts.tsx            # Alert management
│   ├── Resources.tsx         # Emergency resources
│   ├── Encyclopedia.tsx      # Disaster information
│   ├── Report.tsx            # Citizen reporting
│   ├── Login.tsx             # Authentication
│   ├── Profile.tsx           # User settings
│   ├── Admin.tsx             # Admin dashboard
│   └── NotFound.tsx          # 404 page
│
├── lib/                       # Utility functions
│   ├── utils.ts              # General utilities
│   ├── storage.ts            # localStorage wrapper
│   ├── mockData.ts           # Sample data
│   └── disasterUtils.ts      # Disaster-specific helpers
│
├── types/                     # TypeScript definitions
│   └── index.ts              # Type declarations
│
├── hooks/                     # Custom React hooks
│   ├── use-toast.tsx         # Toast notifications
│   ├── use-mobile.ts         # Mobile detection
│   └── use-debounce.ts       # Debounce utility
│
├── routes.tsx                 # Route configuration
├── App.tsx                    # Root component
├── main.tsx                   # Entry point
└── index.css                  # Global styles & design system
```

## 🎨 Design System

### Color Palette

```css
/* Primary Colors */
--primary: 189 100% 50%        /* Neon Blue #00D9FF */
--secondary: 152 100% 50%      /* Neon Green #00FF88 */
--background: 210 100% 6%      /* Deep Navy #0A1929 */

/* Severity Colors */
--low: #00FF88                 /* Green */
--moderate: #FFD93D            /* Yellow */
--high: #FF8C42                /* Orange */
--critical: #FF4444            /* Red */

/* Disaster Type Colors */
--earthquake: #FF6B6B
--flood: #4ECDC4
--cyclone: #95E1D3
--tsunami: #38A3A5
--landslide: #C7B198
--wildfire: #FF8C42
```

### Custom Utility Classes

```css
.glass                  /* Glassmorphism effect */
.glass-card            /* Card with glass effect */
.glow-text             /* Text with glow */
.glow-border           /* Border with glow */
.gradient-text         /* Gradient text effect */
.animate-pulse-glow    /* Pulsing glow animation */
.transition-smooth     /* Smooth transitions */
```

## 🔄 Data Flow

### localStorage Schema

```typescript
// User Authentication
disaster_user: {
  id: string;
  email: string;
  name: string;
  role: 'user' | 'admin';
  createdAt: string;
}

// User Preferences
disaster_preferences: {
  userId: string;
  alertTypes: DisasterType[];
  notificationChannels: ('email' | 'sms' | 'push')[];
  savedLocations: Location[];
  language: string;
}

// Disaster Events
disaster_events: DisasterEvent[]

// Alerts
disaster_alerts: Alert[]

// Citizen Reports
disaster_reports: CitizenReport[]

// Bookmarks
disaster_bookmarks: string[]  // Array of disaster IDs
```

## 🗺️ Google Maps Integration

### Map Configuration

```typescript
const mapOptions = {
  center: { lat: 20, lng: 0 },
  zoom: 2,
  styles: [/* Dark theme styles */],
  mapTypeControl: true,
  mapTypeControlOptions: {
    mapTypeIds: ['roadmap', 'satellite', 'hybrid', 'terrain']
  }
};
```

### Marker System

- **Color-coded by severity:**
  - Green: Low severity
  - Yellow: Moderate severity
  - Orange: High severity
  - Red: Critical severity

- **Interactive InfoWindows:**
  - Disaster title and description
  - Location details
  - Timestamp
  - Click to view full details

### Custom Styling

Dark-themed map with:
- Navy blue landmass
- Darker blue water
- Neon blue labels
- Minimal visual clutter

## 📊 Data Models

### DisasterEvent

```typescript
interface DisasterEvent {
  id: string;
  type: DisasterType;
  title: string;
  description: string;
  location: {
    lat: number;
    lng: number;
    address: string;
    country: string;
  };
  severity: SeverityLevel;
  magnitude?: number;
  timestamp: string;
  affectedArea?: number;
  casualties?: number;
  status: 'active' | 'monitoring' | 'resolved';
  source: string;
  externalLink?: string;
}
```

### Alert

```typescript
interface Alert {
  id: string;
  disasterId: string;
  type: DisasterType;
  severity: SeverityLevel;
  title: string;
  message: string;
  location: string;
  timestamp: string;
  isRead: boolean;
  channels: ('email' | 'sms' | 'push')[];
}
```

### CitizenReport

```typescript
interface CitizenReport {
  id: string;
  type: DisasterType;
  location: {
    lat: number;
    lng: number;
    address: string;
  };
  description: string;
  photos: string[];
  reporterName?: string;
  reporterContact?: string;
  timestamp: string;
  status: 'pending' | 'verified' | 'rejected';
  verifiedBy?: string;
}
```

## 🔐 Authentication Flow

```
1. User visits /login
2. Enters credentials
3. System creates user object
4. Stores in localStorage
5. Redirects to home page
6. Header reads user from localStorage
7. Shows user menu with logout option
```

**Admin Access:**
- Set user.role = 'admin' in localStorage
- Admin panel accessible at /admin
- Can verify/reject citizen reports

## 📈 Analytics Implementation

### Chart Types

1. **Pie Chart** - Disaster type distribution
2. **Bar Chart** - Severity levels
3. **Line Chart** - Timeline trends
4. **Horizontal Bar** - Country statistics

### Data Aggregation

```typescript
// Example: Disaster type distribution
const disasterTypeData = Object.keys(disasterLabels).map(type => ({
  name: disasterLabels[type],
  value: disasters.filter(d => d.type === type).length,
  color: disasterColors[type]
}));
```

## 🎯 Performance Optimizations

1. **Lazy Loading:**
   - Map markers loaded on demand
   - Images lazy loaded with loading="lazy"

2. **Debouncing:**
   - Search inputs debounced
   - Map pan/zoom events throttled

3. **Memoization:**
   - Chart data computed once
   - Filtered lists cached

4. **Code Splitting:**
   - Route-based code splitting with React Router
   - Dynamic imports for heavy components

## 🔌 API Integration Points

### Future Backend Integration

Replace localStorage calls with API calls:

```typescript
// Current (localStorage)
const disasters = storage.getDisasters();

// Future (API)
const disasters = await fetch('/api/disasters').then(r => r.json());
```

### Real-time Data Sources

1. **USGS Earthquake API**
   - Endpoint: `https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/all_day.geojson`
   - Update frequency: Every 5 minutes

2. **NASA FIRMS**
   - Endpoint: `https://firms.modaps.eosdis.nasa.gov/api/area/csv/...`
   - Update frequency: Every 3 hours

3. **NOAA Weather API**
   - Endpoint: `https://api.weather.gov/alerts/active`
   - Update frequency: Real-time

## 🧪 Testing Strategy

### Unit Tests
- Utility functions in `lib/`
- Custom hooks
- Data transformations

### Integration Tests
- Component interactions
- Form submissions
- Navigation flows

### E2E Tests
- User authentication
- Disaster reporting
- Admin workflows

## 🚀 Deployment

### Build Process

```bash
npm run lint    # Type checking and linting
npm run build   # Production build
```

### Environment Variables

```env
VITE_APP_ID=app-7ohd5n562xhd
VITE_API_ENV=production
VITE_GOOGLE_MAPS_API_KEY=your_key_here
```

### Hosting Recommendations

- **Vercel** - Automatic deployments
- **Netlify** - Easy setup
- **AWS S3 + CloudFront** - Scalable
- **Google Cloud Storage** - Cost-effective

## 📱 Mobile Responsiveness

### Breakpoint Strategy

```css
/* Mobile First */
.container { /* Mobile styles */ }

/* Tablet */
@media (min-width: 768px) { /* Tablet styles */ }

/* Desktop */
@media (min-width: 1280px) { /* Desktop styles */ }
```

### Touch Optimization

- Larger touch targets (min 44x44px)
- Swipe gestures for navigation
- Collapsible mobile menu
- Bottom navigation for key actions

## 🔒 Security Considerations

1. **Input Validation:**
   - All form inputs validated
   - XSS prevention
   - SQL injection prevention (when backend added)

2. **Authentication:**
   - JWT tokens (when backend added)
   - Secure session management
   - Role-based access control

3. **API Security:**
   - Rate limiting
   - API key restrictions
   - CORS configuration

## 📚 Dependencies

### Core Dependencies
- react: ^18.0.0
- react-dom: ^18.0.0
- react-router-dom: ^7.9.5
- typescript: ~5.9.3

### UI Libraries
- @radix-ui/*: Various versions
- lucide-react: ^0.553.0
- tailwindcss: ^3.4.11

### Data Visualization
- recharts: ^2.15.3

### Form Handling
- react-hook-form: ^7.66.0
- zod: ^3.25.76

### Utilities
- clsx: ^2.1.1
- date-fns: ^3.6.0

## 🎓 Learning Resources

- [React Documentation](https://react.dev)
- [TypeScript Handbook](https://www.typescriptlang.org/docs/)
- [Tailwind CSS](https://tailwindcss.com/docs)
- [shadcn/ui](https://ui.shadcn.com)
- [Google Maps API](https://developers.google.com/maps/documentation)
- [Recharts](https://recharts.org/en-US/)

---

This architecture is designed to be scalable, maintainable, and production-ready. The modular structure allows for easy feature additions and modifications.
