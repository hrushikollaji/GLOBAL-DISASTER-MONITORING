# 🗺️ How to Get FREE Google Maps API Key

## ✅ 100% FREE - No Credit Card Required Initially

Google Maps provides **$200 FREE credit every month**, which is more than enough for development and small-scale applications!

---

## 📋 Step-by-Step Guide

### Step 1: Create Google Cloud Account

1. **Go to Google Cloud Console**
   - Visit: https://console.cloud.google.com/
   - Click "Get started for free" or "Try for free"

2. **Sign in with Google Account**
   - Use your existing Gmail account
   - Or create a new Google account

3. **Complete Account Setup**
   - Select your country
   - Agree to Terms of Service
   - **Note**: You'll need to add a credit card for verification, BUT:
     - ✅ You get $300 free credit for 90 days
     - ✅ After that, $200 free credit EVERY month
     - ✅ You won't be charged unless you manually upgrade
     - ✅ You'll get alerts before any charges

---

### Step 2: Create a New Project

1. **Click on Project Dropdown**
   - Top left corner, next to "Google Cloud"
   - Click "Select a project"

2. **Create New Project**
   - Click "NEW PROJECT"
   - Project name: `AI-Disaster-Alert` (or any name you like)
   - Organization: Leave as default
   - Location: Leave as default
   - Click "CREATE"

3. **Wait for Project Creation**
   - Takes 10-30 seconds
   - You'll see a notification when ready

---

### Step 3: Enable Required APIs

1. **Go to APIs & Services**
   - Click hamburger menu (☰) on top left
   - Select "APIs & Services" → "Library"

2. **Enable Maps JavaScript API**
   - Search for "Maps JavaScript API"
   - Click on it
   - Click "ENABLE" button
   - Wait for it to enable (5-10 seconds)

3. **Enable Places API**
   - Click "Library" again
   - Search for "Places API"
   - Click on it
   - Click "ENABLE"

4. **Enable Geocoding API**
   - Click "Library" again
   - Search for "Geocoding API"
   - Click on it
   - Click "ENABLE"

---

### Step 4: Create API Key

1. **Go to Credentials**
   - Click "APIs & Services" → "Credentials"

2. **Create Credentials**
   - Click "+ CREATE CREDENTIALS" at top
   - Select "API key"

3. **Copy Your API Key**
   - A popup will show your API key
   - **IMPORTANT**: Copy it immediately!
   - It looks like: `AIzaSyB...` (39 characters)
   - Save it in a safe place

---

### Step 5: Restrict Your API Key (IMPORTANT for Security)

1. **Click "Edit API key"** (or click on the key name)

2. **Set Application Restrictions**
   - Under "Application restrictions"
   - Select "HTTP referrers (web sites)"
   - Click "ADD AN ITEM"
   - Add these referrers:
     ```
     localhost:*
     127.0.0.1:*
     yourdomain.com/*
     *.yourdomain.com/*
     ```
   - Replace `yourdomain.com` with your actual domain

3. **Set API Restrictions**
   - Under "API restrictions"
   - Select "Restrict key"
   - Check these 3 APIs:
     - ✅ Maps JavaScript API
     - ✅ Places API
     - ✅ Geocoding API

4. **Save Changes**
   - Click "SAVE" at bottom

---

### Step 6: Add API Key to Your Project

1. **Open Your Project Folder**
   - Navigate to: `/workspace/app-7ohd5n562xhd/`

2. **Edit index.html**
   - Open `index.html` in any text editor
   - Find line 16:
     ```html
     src="https://maps.googleapis.com/maps/api/js?key=YOUR_API_KEY&callback=initMap&libraries=places"
     ```

3. **Replace YOUR_API_KEY**
   - Replace `YOUR_API_KEY` with your actual API key
   - Example:
     ```html
     src="https://maps.googleapis.com/maps/api/js?key=AIzaSyB1234567890abcdefghijklmnopqrstu&callback=initMap&libraries=places"
     ```

4. **Save the File**

---

## 💰 Pricing Information

### FREE Tier (More than enough!)

**Monthly Free Credit**: $200

**What you get for FREE:**
- **Maps JavaScript API**: 28,000 map loads per month
- **Places API**: 28,000 requests per month
- **Geocoding API**: 40,000 requests per month

**For this project:**
- Average usage: ~$5-20 per month (well within free tier)
- You can handle 1,000+ daily users for FREE

### Cost Calculator

Use Google's pricing calculator to estimate:
https://mapsplatform.google.com/pricing/

---

## 🔒 Security Best Practices

### 1. Never Commit API Keys to GitHub

Add to `.gitignore`:
```
.env
.env.local
```

### 2. Use Environment Variables (Optional)

Instead of hardcoding in HTML, you can use:
```javascript
const API_KEY = import.meta.env.VITE_GOOGLE_MAPS_API_KEY;
```

### 3. Set Up Billing Alerts

1. Go to "Billing" in Google Cloud Console
2. Click "Budgets & alerts"
3. Create a budget alert for $10
4. You'll get email notifications

### 4. Monitor Usage

1. Go to "APIs & Services" → "Dashboard"
2. View your API usage
3. Check daily/monthly statistics

---

## 🚨 Common Issues & Solutions

### Issue 1: "This page can't load Google Maps correctly"

**Solution:**
- Check if API key is correct
- Verify all 3 APIs are enabled
- Check browser console for specific error
- Wait 5 minutes after enabling APIs

### Issue 2: "RefererNotAllowedMapError"

**Solution:**
- Add your domain to HTTP referrers
- For local development, add:
  - `localhost:*`
  - `127.0.0.1:*`

### Issue 3: "ApiNotActivatedMapError"

**Solution:**
- Go back to API Library
- Enable all 3 required APIs:
  - Maps JavaScript API
  - Places API
  - Geocoding API

### Issue 4: Map shows but is grayed out

**Solution:**
- Billing must be enabled (even for free tier)
- Add credit card for verification
- You won't be charged within free tier

---

## 📊 Monitoring Your Usage

### Check Current Usage

1. Go to Google Cloud Console
2. Click "APIs & Services" → "Dashboard"
3. View metrics for each API
4. Check daily/monthly usage

### Set Up Alerts

1. Go to "Billing" → "Budgets & alerts"
2. Create budget: $10
3. Set alert thresholds:
   - 50% of budget
   - 90% of budget
   - 100% of budget

---

## 🎯 Testing Your API Key

### Quick Test

1. Open your browser
2. Open Developer Console (F12)
3. Go to your application
4. Check for errors in Console tab
5. If map loads, you're good! ✅

### Verify API Calls

1. Go to Google Cloud Console
2. "APIs & Services" → "Dashboard"
3. Click on "Maps JavaScript API"
4. Check "Metrics" tab
5. You should see requests being logged

---

## 💡 Pro Tips

### 1. Use API Key Restrictions
Always restrict your API key to prevent unauthorized use

### 2. Monitor Usage Weekly
Check your usage every week to avoid surprises

### 3. Use Caching
Implement caching to reduce API calls:
```javascript
// Cache geocoding results
const cache = new Map();
```

### 4. Optimize Map Loads
- Load map only when needed
- Use static maps for thumbnails
- Implement lazy loading

### 5. Development vs Production Keys
- Use separate API keys for development and production
- Restrict production key to your domain only

---

## 📞 Need Help?

### Google Maps Support
- Documentation: https://developers.google.com/maps/documentation
- Support: https://developers.google.com/maps/support
- Community: https://stackoverflow.com/questions/tagged/google-maps

### Billing Questions
- Billing Support: https://cloud.google.com/support
- Pricing Calculator: https://mapsplatform.google.com/pricing/

---

## ✅ Checklist

Before deploying, make sure:

- [ ] Google Cloud account created
- [ ] Project created
- [ ] All 3 APIs enabled (Maps JavaScript, Places, Geocoding)
- [ ] API key created
- [ ] API key restrictions set
- [ ] API key added to index.html
- [ ] Billing enabled (for free tier)
- [ ] Budget alerts configured
- [ ] API key tested and working
- [ ] Usage monitoring set up

---

## 🎉 You're All Set!

Your Google Maps API is now configured and ready to use **100% FREE** within the generous free tier limits!

**Remember:**
- ✅ $200 free credit every month
- ✅ No charges within free tier
- ✅ Alerts before any charges
- ✅ Perfect for development and small apps

---

**Last Updated**: November 2025
**Status**: ✅ Verified Working
