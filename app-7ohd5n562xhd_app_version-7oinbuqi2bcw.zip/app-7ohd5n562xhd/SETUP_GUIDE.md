# AI Disaster Alert Platform - Setup Guide

## 🚀 Quick Start

Your AI-powered disaster management platform is ready! Follow these steps to get started.

## 📋 Prerequisites

- Node.js 18+ installed
- Google Maps API key (required for map functionality)
- Modern web browser

## 🔧 Configuration Steps

### 1. Google Maps API Setup

**Get Your API Key:**
1. Go to [Google Cloud Console](https://console.cloud.google.com/)
2. Create a new project or select an existing one
3. Enable the following APIs:
   - Maps JavaScript API
   - Places API
   - Geocoding API
4. Create credentials (API Key)
5. Restrict your API key (recommended):
   - HTTP referrers: Add your domain
   - API restrictions: Select the APIs listed above

**Add API Key to Project:**
1. Open `index.html` in the root directory
2. Find line 16: `src="https://maps.googleapis.com/maps/api/js?key=YOUR_API_KEY&callback=initMap&libraries=places"`
3. Replace `YOUR_API_KEY` with your actual Google Maps API key

### 2. Environment Variables

The `.env` file is already configured with default values:
```
VITE_LOGIN_TYPE=gmail
VITE_APP_ID=app-7ohd5n562xhd
VITE_API_ENV=production
VITE_GOOGLE_MAPS_API_KEY=your_google_maps_api_key_here
```

You can update `VITE_GOOGLE_MAPS_API_KEY` if you want to use it in your code instead of hardcoding in HTML.

## 🎨 Features Overview

### Core Pages

1. **Home** (`/`)
   - Interactive Google Maps with disaster markers
   - Real-time disaster statistics
   - Color-coded severity indicators
   - Recent disasters feed

2. **Analytics** (`/analytics`)
   - Disaster type distribution (Pie Chart)
   - Severity analysis (Bar Chart)
   - Timeline trends (Line Chart)
   - Country-wise statistics

3. **Alerts** (`/alerts`)
   - Active alerts dashboard
   - Alert history
   - Multi-channel notification preferences
   - Mark as read functionality

4. **Resources** (`/resources`)
   - Emergency contact directory
   - Shelter locator with capacity info
   - External resource links
   - Navigation to shelters

5. **Encyclopedia** (`/encyclopedia`)
   - Comprehensive disaster information
   - Safety guidelines
   - Preparation tips
   - Causes and effects

6. **Report Disaster** (`/report`)
   - Citizen reporting form
   - Location picker
   - Photo upload capability
   - Anonymous reporting option

7. **Profile** (`/profile`)
   - User account management
   - Alert preferences
   - Notification channel selection
   - Saved locations

8. **Admin Dashboard** (`/admin`)
   - Report moderation
   - Verify/reject citizen reports
   - System statistics
   - User management

### Authentication

- Simple login/signup system using localStorage
- No backend required for demo purposes
- User roles: `user` and `admin`
- Session persistence across page reloads

## 🎯 Data Storage

**Current Implementation:**
- Uses browser localStorage for data persistence
- Mock disaster data included for demonstration
- All user data stored locally

**Note:** Supabase backend was unavailable during development. To integrate a real backend:
1. Set up Supabase project
2. Create tables for disasters, alerts, reports, shelters
3. Replace localStorage calls in `src/lib/storage.ts` with Supabase queries
4. Update authentication to use Supabase Auth

## 🎨 Design System

**Color Scheme:**
- Primary: Neon Blue (#00D9FF)
- Secondary: Neon Green (#00FF88)
- Background: Deep Navy (#0A1929)
- Glassmorphism effects throughout

**Typography:**
- Gradient text for headings
- High contrast for readability
- Responsive font sizes

**Components:**
- shadcn/ui component library
- Custom cyber-tech styling
- Smooth animations and transitions

## 📱 Responsive Design

- Desktop-first approach
- Breakpoints:
  - Mobile: < 768px
  - Tablet: 768px - 1279px
  - Desktop: 1280px+
- Touch-friendly mobile interface
- Collapsible navigation on mobile

## 🔌 API Integration (Future Enhancement)

To integrate real disaster data APIs:

### USGS Earthquake API
```javascript
const response = await fetch('https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/all_day.geojson');
const data = await response.json();
```

### NASA FIRMS (Wildfire)
```javascript
const response = await fetch('https://firms.modaps.eosdis.nasa.gov/api/area/csv/...');
```

### NOAA Weather API
```javascript
const response = await fetch('https://api.weather.gov/alerts/active');
```

Update `src/lib/mockData.ts` to fetch from these APIs instead of using mock data.

## 🚨 Important Notes

1. **Google Maps API Key**: The map will not work without a valid API key
2. **Data Persistence**: Currently uses localStorage - data is browser-specific
3. **Supabase**: Backend integration pending - contact Miaoda support for assistance
4. **Real-time Updates**: Mock data is static - integrate live APIs for real-time functionality
5. **Image Upload**: Photo upload in citizen reports is UI-only - needs backend integration

## 🛠️ Development

```bash
# Install dependencies (if needed)
pnpm install

# Run linting
npm run lint

# The application is ready to deploy
```

## 📊 Mock Data

The platform includes sample data for:
- 8 disaster events (earthquakes, wildfires, cyclones, floods, tsunamis, landslides)
- 3 emergency shelters
- 3 AI prediction scenarios

To add more data, edit `src/lib/mockData.ts`

## 🎓 For Presentations

This platform is perfect for:
- University seminars and projects
- Hackathon demonstrations
- Disaster management research
- Emergency response training
- Public awareness campaigns

## 📞 Support

**Supabase Integration:**
If you need help integrating Supabase backend, please contact Miaoda official support.

**Google Maps Issues:**
- Verify API key is correct
- Check API restrictions
- Ensure billing is enabled on Google Cloud
- Check browser console for errors

## 🔐 Security Notes

- Never commit your Google Maps API key to public repositories
- Use environment variables for sensitive data
- Implement proper authentication for production
- Add rate limiting for API calls
- Validate all user inputs

## 📈 Future Enhancements

1. Real-time data integration from disaster APIs
2. WebSocket for live updates
3. Push notifications
4. SMS/Email alerts
5. Machine learning predictions
6. Multi-language support
7. Mobile app version
8. Offline mode with service workers

## 🎉 You're All Set!

Your AI Disaster Alert Platform is ready to use. The application features a stunning cyber-tech design with full disaster monitoring capabilities. Simply add your Google Maps API key and you're good to go!
