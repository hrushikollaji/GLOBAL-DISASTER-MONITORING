import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { AlertTriangle, Waves, Wind, Mountain, Flame, Activity } from "lucide-react";
import type { DisasterType } from "@/types";

const disasterInfo: Record<DisasterType, {
  icon: React.ReactNode;
  title: string;
  description: string;
  causes: string[];
  safety: string[];
  preparation: string[];
}> = {
  earthquake: {
    icon: <Activity className="h-8 w-8" />,
    title: "Earthquakes",
    description: "Sudden shaking of the ground caused by the movement of tectonic plates beneath the Earth's surface.",
    causes: [
      "Movement of tectonic plates",
      "Volcanic activity",
      "Human activities (mining, reservoir-induced seismicity)",
      "Fault line ruptures"
    ],
    safety: [
      "Drop, Cover, and Hold On during shaking",
      "Stay away from windows and heavy objects",
      "If outdoors, move to an open area",
      "If in a vehicle, pull over and stay inside"
    ],
    preparation: [
      "Secure heavy furniture and appliances",
      "Create an emergency kit with supplies",
      "Identify safe spots in each room",
      "Practice earthquake drills regularly"
    ]
  },
  flood: {
    icon: <Waves className="h-8 w-8" />,
    title: "Floods",
    description: "Overflow of water onto normally dry land, often caused by heavy rainfall, storm surges, or dam failures.",
    causes: [
      "Heavy or prolonged rainfall",
      "Storm surges from hurricanes",
      "Rapid snowmelt",
      "Dam or levee failures"
    ],
    safety: [
      "Move to higher ground immediately",
      "Never walk or drive through floodwater",
      "Avoid contact with floodwater (contamination risk)",
      "Listen to emergency broadcasts"
    ],
    preparation: [
      "Know your flood risk and evacuation routes",
      "Elevate utilities and valuables",
      "Install check valves in plumbing",
      "Purchase flood insurance"
    ]
  },
  cyclone: {
    icon: <Wind className="h-8 w-8" />,
    title: "Cyclones/Hurricanes",
    description: "Rapidly rotating storm systems with strong winds, heavy rain, and storm surges.",
    causes: [
      "Warm ocean waters (above 26°C)",
      "Low atmospheric pressure",
      "Coriolis effect from Earth's rotation",
      "Moisture and instability in atmosphere"
    ],
    safety: [
      "Evacuate if ordered by authorities",
      "Stay indoors away from windows",
      "Go to interior room or basement",
      "Avoid using candles (fire risk)"
    ],
    preparation: [
      "Board up windows and secure outdoor items",
      "Stock emergency supplies for several days",
      "Fill bathtubs with water",
      "Charge all electronic devices"
    ]
  },
  tsunami: {
    icon: <Waves className="h-8 w-8" />,
    title: "Tsunamis",
    description: "Series of ocean waves caused by underwater earthquakes, volcanic eruptions, or landslides.",
    causes: [
      "Undersea earthquakes",
      "Volcanic eruptions",
      "Underwater landslides",
      "Meteorite impacts (rare)"
    ],
    safety: [
      "Move to high ground immediately",
      "Stay away from coast for several hours",
      "Never go to beach to watch tsunami",
      "Listen for official all-clear signal"
    ],
    preparation: [
      "Know tsunami warning signs",
      "Plan evacuation routes to high ground",
      "Practice evacuation drills",
      "Keep emergency kit ready"
    ]
  },
  landslide: {
    icon: <Mountain className="h-8 w-8" />,
    title: "Landslides",
    description: "Movement of rock, earth, or debris down a slope due to gravity.",
    causes: [
      "Heavy rainfall saturating soil",
      "Earthquakes triggering slope failure",
      "Volcanic activity",
      "Human activities (deforestation, construction)"
    ],
    safety: [
      "Evacuate if landslide is imminent",
      "Move perpendicular to landslide path",
      "Curl into tight ball if caught",
      "Alert neighbors if safe to do so"
    ],
    preparation: [
      "Plant ground cover on slopes",
      "Build retaining walls",
      "Monitor slope for warning signs",
      "Avoid building on steep slopes"
    ]
  },
  wildfire: {
    icon: <Flame className="h-8 w-8" />,
    title: "Wildfires",
    description: "Uncontrolled fires in vegetation areas, spreading rapidly through forests and grasslands.",
    causes: [
      "Lightning strikes",
      "Human negligence (campfires, cigarettes)",
      "Arson",
      "Dry conditions and high winds"
    ],
    safety: [
      "Evacuate immediately if ordered",
      "Close all windows and doors",
      "Wear protective clothing",
      "Stay low to avoid smoke inhalation"
    ],
    preparation: [
      "Create defensible space around property",
      "Use fire-resistant building materials",
      "Keep gutters clear of debris",
      "Have evacuation plan ready"
    ]
  }
};

export default function Encyclopedia() {
  const [selectedType, setSelectedType] = useState<DisasterType>('earthquake');
  const info = disasterInfo[selectedType];

  return (
    <div className="min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold gradient-text mb-2">
            Disaster Encyclopedia
          </h1>
          <p className="text-muted-foreground">
            Learn about different types of disasters and how to stay safe
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-4 mb-8">
          {(Object.keys(disasterInfo) as DisasterType[]).map(type => (
            <Card
              key={type}
              className={`glass-card cursor-pointer transition-smooth ${
                selectedType === type ? 'border-primary glow-border' : 'hover:border-primary/50'
              }`}
              onClick={() => setSelectedType(type)}
            >
              <CardContent className="p-4 text-center">
                <div className="text-primary mb-2 flex justify-center">
                  {disasterInfo[type].icon}
                </div>
                <p className="text-sm font-medium">{disasterInfo[type].title}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        <Card className="glass-card">
          <CardHeader>
            <div className="flex items-center gap-3">
              <div className="text-primary">{info.icon}</div>
              <CardTitle className="text-2xl">{info.title}</CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground mb-6">{info.description}</p>

            <Tabs defaultValue="causes" className="space-y-4">
              <TabsList className="glass-card">
                <TabsTrigger value="causes">Causes</TabsTrigger>
                <TabsTrigger value="safety">Safety Tips</TabsTrigger>
                <TabsTrigger value="preparation">Preparation</TabsTrigger>
              </TabsList>

              <TabsContent value="causes">
                <Card className="border-border">
                  <CardHeader>
                    <CardTitle className="text-lg">What Causes {info.title}?</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2">
                      {info.causes.map((cause, index) => (
                        <li key={index} className="flex items-start gap-2">
                          <AlertTriangle className="h-4 w-4 text-primary shrink-0 mt-1" />
                          <span className="text-muted-foreground">{cause}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="safety">
                <Card className="border-border">
                  <CardHeader>
                    <CardTitle className="text-lg">Safety Guidelines</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2">
                      {info.safety.map((tip, index) => (
                        <li key={index} className="flex items-start gap-2">
                          <AlertTriangle className="h-4 w-4 text-secondary shrink-0 mt-1" />
                          <span className="text-muted-foreground">{tip}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="preparation">
                <Card className="border-border">
                  <CardHeader>
                    <CardTitle className="text-lg">How to Prepare</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2">
                      {info.preparation.map((step, index) => (
                        <li key={index} className="flex items-start gap-2">
                          <AlertTriangle className="h-4 w-4 text-primary shrink-0 mt-1" />
                          <span className="text-muted-foreground">{step}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
