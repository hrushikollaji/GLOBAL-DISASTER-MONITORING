import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Search, TrendingUp, AlertTriangle, Activity, Flame, Waves } from "lucide-react";
import { DisasterMap } from "@/components/map/DisasterMap";
import { EmergencyAlert } from "@/components/emergency/EmergencyAlert";
import { EmergencyContacts } from "@/components/emergency/EmergencyContacts";
import { fetchEarthquakes, type EarthquakeData } from "@/lib/disasterApis";
import { severityColors, formatTimestamp } from "@/lib/disasterUtils";

export default function Home() {
  const [recentEarthquakes, setRecentEarthquakes] = useState<EarthquakeData[]>([]);
  const [criticalAlerts, setCriticalAlerts] = useState<EarthquakeData[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [stats, setStats] = useState({
    total: 0,
    active: 0,
    critical: 0,
    monitoring: 0,
  });

  useEffect(() => {
    const loadData = async () => {
      const earthquakes = await fetchEarthquakes();
      setRecentEarthquakes(earthquakes.slice(0, 10));
      
      const critical = earthquakes.filter(e => e.magnitude >= 5.5);
      setCriticalAlerts(critical.slice(0, 3));
      
      setStats({
        total: earthquakes.length,
        active: earthquakes.filter(e => e.magnitude >= 4).length,
        critical: critical.length,
        monitoring: earthquakes.filter(e => e.magnitude < 4).length,
      });
    };

    loadData();
    
    const interval = setInterval(loadData, 5 * 60 * 1000);
    
    return () => clearInterval(interval);
  }, []);

  const filteredEarthquakes = recentEarthquakes.filter(eq =>
    eq.location.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold gradient-text mb-2">
            Global Disaster Monitoring
          </h1>
          <p className="text-muted-foreground">
            Real-time tracking from USGS, NASA FIRMS, and OpenWeatherMap APIs
          </p>
        </div>

        {criticalAlerts.length > 0 && (
          <div className="mb-6 space-y-4">
            {criticalAlerts.map((alert) => (
              <EmergencyAlert
                key={alert.id}
                title={`Magnitude ${alert.magnitude.toFixed(1)} Earthquake`}
                message={`A significant earthquake has been detected. Stay alert and follow safety protocols. Depth: ${alert.depth.toFixed(1)} km.`}
                severity={alert.magnitude >= 7 ? 'critical' : 'high'}
                location={alert.location}
                emergencyNumbers={['911', '112', '1078']}
              />
            ))}
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4 mb-8">
          <Card className="glass-card">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <Activity className="h-4 w-4 text-primary" />
                Total Events (24h)
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-foreground">{stats.total}</div>
              <p className="text-xs text-muted-foreground mt-1">Live from USGS</p>
            </CardContent>
          </Card>

          <Card className="glass-card">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <AlertTriangle className="h-4 w-4 text-destructive" />
                Active Disasters
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-destructive">{stats.active}</div>
              <p className="text-xs text-muted-foreground mt-1">Magnitude ≥ 4.0</p>
            </CardContent>
          </Card>

          <Card className="glass-card">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <TrendingUp className="h-4 w-4" style={{ color: severityColors.critical }} />
                Critical Level
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold" style={{ color: severityColors.critical }}>
                {stats.critical}
              </div>
              <p className="text-xs text-muted-foreground mt-1">Magnitude ≥ 5.5</p>
            </CardContent>
          </Card>

          <Card className="glass-card">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <Waves className="h-4 w-4" style={{ color: severityColors.moderate }} />
                Monitoring
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold" style={{ color: severityColors.moderate }}>
                {stats.monitoring}
              </div>
              <p className="text-xs text-muted-foreground mt-1">Minor events</p>
            </CardContent>
          </Card>
        </div>

        <div className="mb-6">
          <EmergencyContacts />
        </div>

        <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
          <div className="xl:col-span-2 space-y-6">
            <DisasterMap />
            
            <Card className="glass-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Flame className="h-5 w-5 text-primary" />
                  Data Sources
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="p-3 rounded-lg border border-border">
                    <h4 className="font-semibold text-sm mb-1">USGS Earthquakes</h4>
                    <p className="text-xs text-muted-foreground">Real-time seismic data</p>
                    <Badge variant="outline" className="mt-2 text-xs">
                      ✅ Live
                    </Badge>
                  </div>
                  <div className="p-3 rounded-lg border border-border">
                    <h4 className="font-semibold text-sm mb-1">NASA FIRMS</h4>
                    <p className="text-xs text-muted-foreground">Wildfire detection</p>
                    <Badge variant="outline" className="mt-2 text-xs">
                      ✅ Live
                    </Badge>
                  </div>
                  <div className="p-3 rounded-lg border border-border">
                    <h4 className="font-semibold text-sm mb-1">GDACS Cyclones</h4>
                    <p className="text-xs text-muted-foreground">Tropical storm tracking</p>
                    <Badge variant="outline" className="mt-2 text-xs">
                      ✅ Live
                    </Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="space-y-6">
            <Card className="glass-card">
              <CardHeader>
                <CardTitle>Recent Earthquakes</CardTitle>
                <div className="relative mt-2">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search location..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </CardHeader>
              <CardContent className="space-y-3 max-h-[600px] overflow-y-auto">
                {filteredEarthquakes.length === 0 ? (
                  <p className="text-sm text-muted-foreground text-center py-4">
                    No earthquakes found
                  </p>
                ) : (
                  filteredEarthquakes.map((eq) => {
                    const color = eq.magnitude >= 5.5 ? severityColors.critical :
                                 eq.magnitude >= 4 ? severityColors.high :
                                 eq.magnitude >= 2.5 ? severityColors.moderate :
                                 severityColors.low;
                    
                    return (
                      <div
                        key={eq.id}
                        className="p-3 rounded-lg border border-border hover:border-primary/50 transition-smooth cursor-pointer"
                      >
                        <div className="flex items-start justify-between gap-2 mb-2">
                          <Badge 
                            variant="outline" 
                            className="text-xs"
                            style={{ 
                              borderColor: color,
                              color: color
                            }}
                          >
                            M{eq.magnitude.toFixed(1)}
                          </Badge>
                          <span className="text-xs text-muted-foreground">
                            {formatTimestamp(eq.time)}
                          </span>
                        </div>
                        <h4 className="font-semibold text-sm mb-1">{eq.location}</h4>
                        <p className="text-xs text-muted-foreground">
                          Depth: {eq.depth.toFixed(1)} km
                        </p>
                      </div>
                    );
                  })
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
