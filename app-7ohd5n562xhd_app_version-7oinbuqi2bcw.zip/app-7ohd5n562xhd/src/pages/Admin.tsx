import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Shield, FileText, AlertTriangle, Users, CheckCircle, XCircle } from "lucide-react";
import { storage } from "@/lib/storage";
import { useToast } from "@/hooks/use-toast";
import type { CitizenReport } from "@/types";
import { disasterLabels, severityColors, formatTimestamp } from "@/lib/disasterUtils";

export default function Admin() {
  const { toast } = useToast();
  const [user, setUser] = useState(storage.getUser());
  const [reports, setReports] = useState<CitizenReport[]>([]);

  useEffect(() => {
    setReports(storage.getReports());
  }, []);

  const handleVerify = (reportId: string) => {
    const updatedReports = reports.map(r =>
      r.id === reportId ? { ...r, status: 'verified' as const, verifiedBy: user?.name } : r
    );
    setReports(updatedReports);
    storage.setReports(updatedReports);
    toast({
      title: "Report Verified",
      description: "The report has been marked as verified.",
    });
  };

  const handleReject = (reportId: string) => {
    const updatedReports = reports.map(r =>
      r.id === reportId ? { ...r, status: 'rejected' as const } : r
    );
    setReports(updatedReports);
    storage.setReports(updatedReports);
    toast({
      title: "Report Rejected",
      description: "The report has been marked as rejected.",
      variant: "destructive"
    });
  };

  if (!user || user.role !== 'admin') {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="glass-card">
          <CardContent className="py-12 text-center">
            <Shield className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground">Access Denied: Admin privileges required</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const pendingReports = reports.filter(r => r.status === 'pending');
  const verifiedReports = reports.filter(r => r.status === 'verified');
  const rejectedReports = reports.filter(r => r.status === 'rejected');

  return (
    <div className="min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold gradient-text mb-2">
            Admin Dashboard
          </h1>
          <p className="text-muted-foreground">
            Manage disaster reports and system settings
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          <Card className="glass-card">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <FileText className="h-4 w-4 text-primary" />
                Pending Reports
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-primary">{pendingReports.length}</div>
            </CardContent>
          </Card>

          <Card className="glass-card">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <CheckCircle className="h-4 w-4 text-secondary" />
                Verified Reports
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-secondary">{verifiedReports.length}</div>
            </CardContent>
          </Card>

          <Card className="glass-card">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <XCircle className="h-4 w-4 text-destructive" />
                Rejected Reports
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-destructive">{rejectedReports.length}</div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="pending" className="space-y-6">
          <TabsList className="glass-card">
            <TabsTrigger value="pending">
              Pending ({pendingReports.length})
            </TabsTrigger>
            <TabsTrigger value="verified">
              Verified ({verifiedReports.length})
            </TabsTrigger>
            <TabsTrigger value="rejected">
              Rejected ({rejectedReports.length})
            </TabsTrigger>
          </TabsList>

          <TabsContent value="pending" className="space-y-4">
            {pendingReports.length === 0 ? (
              <Card className="glass-card">
                <CardContent className="py-12 text-center">
                  <FileText className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <p className="text-muted-foreground">No pending reports</p>
                </CardContent>
              </Card>
            ) : (
              pendingReports.map(report => (
                <Card key={report.id} className="glass-card">
                  <CardHeader>
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <Badge variant="outline">
                            {disasterLabels[report.type]}
                          </Badge>
                          <Badge variant="secondary">Pending Review</Badge>
                        </div>
                        <CardTitle className="text-lg">{report.location.address}</CardTitle>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <p className="text-sm text-muted-foreground">{report.description}</p>
                    <div className="text-xs text-muted-foreground">
                      <p>Reported: {formatTimestamp(report.timestamp)}</p>
                      {report.reporterName && <p>Reporter: {report.reporterName}</p>}
                      {report.reporterContact && <p>Contact: {report.reporterContact}</p>}
                    </div>
                    <div className="flex gap-2">
                      <Button
                        onClick={() => handleVerify(report.id)}
                        className="flex-1"
                        variant="default"
                      >
                        <CheckCircle className="h-4 w-4 mr-2" />
                        Verify
                      </Button>
                      <Button
                        onClick={() => handleReject(report.id)}
                        className="flex-1"
                        variant="destructive"
                      >
                        <XCircle className="h-4 w-4 mr-2" />
                        Reject
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </TabsContent>

          <TabsContent value="verified" className="space-y-4">
            {verifiedReports.map(report => (
              <Card key={report.id} className="glass-card border-secondary">
                <CardHeader>
                  <div className="flex items-center gap-2 mb-2">
                    <Badge variant="outline">{disasterLabels[report.type]}</Badge>
                    <Badge className="bg-secondary text-secondary-foreground">Verified</Badge>
                  </div>
                  <CardTitle className="text-lg">{report.location.address}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground mb-2">{report.description}</p>
                  <p className="text-xs text-muted-foreground">
                    Verified by: {report.verifiedBy || 'Admin'}
                  </p>
                </CardContent>
              </Card>
            ))}
          </TabsContent>

          <TabsContent value="rejected" className="space-y-4">
            {rejectedReports.map(report => (
              <Card key={report.id} className="glass-card border-destructive/50">
                <CardHeader>
                  <div className="flex items-center gap-2 mb-2">
                    <Badge variant="outline">{disasterLabels[report.type]}</Badge>
                    <Badge variant="destructive">Rejected</Badge>
                  </div>
                  <CardTitle className="text-lg">{report.location.address}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">{report.description}</p>
                </CardContent>
              </Card>
            ))}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
