import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { BarChart, Bar, PieChart, Pie, Cell, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import { TrendingUp, BarChart3, PieChart as PieChartIcon, Activity } from "lucide-react";
import type { DisasterEvent } from "@/types";
import { storage } from "@/lib/storage";
import { mockDisasters } from "@/lib/mockData";
import { disasterLabels, severityColors, disasterColors } from "@/lib/disasterUtils";

export default function Analytics() {
  const [disasters, setDisasters] = useState<DisasterEvent[]>([]);

  useEffect(() => {
    const storedDisasters = storage.getDisasters();
    if (storedDisasters.length === 0) {
      storage.setDisasters(mockDisasters);
      setDisasters(mockDisasters);
    } else {
      setDisasters(storedDisasters);
    }
  }, []);

  const disasterTypeData = Object.keys(disasterLabels).map(type => ({
    name: disasterLabels[type as keyof typeof disasterLabels],
    value: disasters.filter(d => d.type === type).length,
    color: disasterColors[type as keyof typeof disasterColors]
  }));

  const severityData = [
    { name: 'Low', value: disasters.filter(d => d.severity === 'low').length, color: severityColors.low },
    { name: 'Moderate', value: disasters.filter(d => d.severity === 'moderate').length, color: severityColors.moderate },
    { name: 'High', value: disasters.filter(d => d.severity === 'high').length, color: severityColors.high },
    { name: 'Critical', value: disasters.filter(d => d.severity === 'critical').length, color: severityColors.critical },
  ];

  const timelineData = disasters
    .sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime())
    .slice(-7)
    .map(d => ({
      date: new Date(d.timestamp).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
      count: 1
    }))
    .reduce((acc, curr) => {
      const existing = acc.find(item => item.date === curr.date);
      if (existing) {
        existing.count += 1;
      } else {
        acc.push(curr);
      }
      return acc;
    }, [] as { date: string; count: number }[]);

  const countryData = disasters
    .reduce((acc, d) => {
      const country = d.location.country;
      const existing = acc.find(item => item.country === country);
      if (existing) {
        existing.count += 1;
      } else {
        acc.push({ country, count: 1 });
      }
      return acc;
    }, [] as { country: string; count: number }[])
    .sort((a, b) => b.count - a.count)
    .slice(0, 10);

  return (
    <div className="min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold gradient-text mb-2">
            Disaster Analytics
          </h1>
          <p className="text-muted-foreground">
            Statistical analysis and trends of global disaster events
          </p>
        </div>

        <div className="grid grid-cols-1 xl:grid-cols-2 gap-6 mb-6">
          <Card className="glass-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <PieChartIcon className="h-5 w-5 text-primary" />
                Disasters by Type
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={disasterTypeData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                    outerRadius={100}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {disasterTypeData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'hsl(210 50% 8%)', 
                      border: '1px solid hsl(210 30% 20%)',
                      borderRadius: '8px'
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <Card className="glass-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="h-5 w-5 text-primary" />
                Severity Distribution
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={severityData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(210 30% 20%)" />
                  <XAxis dataKey="name" stroke="hsl(0 0% 100%)" />
                  <YAxis stroke="hsl(0 0% 100%)" />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'hsl(210 50% 8%)', 
                      border: '1px solid hsl(210 30% 20%)',
                      borderRadius: '8px'
                    }}
                  />
                  <Bar dataKey="value" radius={[8, 8, 0, 0]}>
                    {severityData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
          <Card className="glass-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5 text-primary" />
                Recent Activity Timeline
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={timelineData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(210 30% 20%)" />
                  <XAxis dataKey="date" stroke="hsl(0 0% 100%)" />
                  <YAxis stroke="hsl(0 0% 100%)" />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'hsl(210 50% 8%)', 
                      border: '1px solid hsl(210 30% 20%)',
                      borderRadius: '8px'
                    }}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="count" 
                    stroke="hsl(189 100% 50%)" 
                    strokeWidth={3}
                    dot={{ fill: 'hsl(189 100% 50%)', r: 6 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <Card className="glass-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Activity className="h-5 w-5 text-primary" />
                Top Affected Countries
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={countryData} layout="vertical">
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(210 30% 20%)" />
                  <XAxis type="number" stroke="hsl(0 0% 100%)" />
                  <YAxis dataKey="country" type="category" stroke="hsl(0 0% 100%)" width={100} />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'hsl(210 50% 8%)', 
                      border: '1px solid hsl(210 30% 20%)',
                      borderRadius: '8px'
                    }}
                  />
                  <Bar dataKey="count" fill="hsl(152 100% 50%)" radius={[0, 8, 8, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
