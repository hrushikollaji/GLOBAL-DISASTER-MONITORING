import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Phone, MapPin, Navigation, Users, Search, ExternalLink } from "lucide-react";
import type { EmergencyShelter } from "@/types";
import { mockShelters } from "@/lib/mockData";

export default function Resources() {
  const [shelters, setShelters] = useState<EmergencyShelter[]>([]);
  const [searchQuery, setSearchQuery] = useState("");

  useEffect(() => {
    setShelters(mockShelters);
  }, []);

  const filteredShelters = shelters.filter(s =>
    s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    s.location.address.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const emergencyContacts = [
    { name: "Emergency Services", number: "911", region: "USA" },
    { name: "Emergency Services", number: "112", region: "Europe" },
    { name: "Emergency Services", number: "999", region: "UK" },
    { name: "FEMA", number: "1-800-621-3362", region: "USA" },
    { name: "Red Cross", number: "1-800-733-2767", region: "USA" },
    { name: "WHO Emergency", number: "+41 22 791 21 11", region: "Global" },
  ];

  return (
    <div className="min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold gradient-text mb-2">
            Emergency Resources
          </h1>
          <p className="text-muted-foreground">
            Find emergency contacts, shelters, and safety information
          </p>
        </div>

        <div className="grid grid-cols-1 xl:grid-cols-2 gap-6 mb-8">
          <Card className="glass-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Phone className="h-5 w-5 text-primary" />
                Emergency Contacts
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {emergencyContacts.map((contact, index) => (
                <div key={index} className="flex items-center justify-between p-3 rounded-lg border border-border hover:border-primary/50 transition-smooth">
                  <div>
                    <h4 className="font-semibold text-sm">{contact.name}</h4>
                    <p className="text-xs text-muted-foreground">{contact.region}</p>
                  </div>
                  <a href={`tel:${contact.number}`} className="text-primary font-mono text-sm hover:underline">
                    {contact.number}
                  </a>
                </div>
              ))}
            </CardContent>
          </Card>

          <Card className="glass-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <ExternalLink className="h-5 w-5 text-primary" />
                Useful Resources
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {[
                { name: "USGS Earthquake Hazards", url: "https://earthquake.usgs.gov" },
                { name: "NASA FIRMS", url: "https://firms.modaps.eosdis.nasa.gov" },
                { name: "NOAA Weather", url: "https://www.weather.gov" },
                { name: "GDACS", url: "https://www.gdacs.org" },
                { name: "Red Cross Preparedness", url: "https://www.redcross.org/get-help/how-to-prepare-for-emergencies.html" },
                { name: "FEMA", url: "https://www.fema.gov" },
              ].map((resource, index) => (
                <Button
                  key={index}
                  variant="outline"
                  className="w-full justify-between"
                  onClick={() => window.open(resource.url, '_blank')}
                >
                  <span>{resource.name}</span>
                  <ExternalLink className="h-4 w-4" />
                </Button>
              ))}
            </CardContent>
          </Card>
        </div>

        <Card className="glass-card">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <MapPin className="h-5 w-5 text-primary" />
                Emergency Shelters
              </CardTitle>
              <div className="relative w-64">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search shelters..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
              {filteredShelters.map(shelter => (
                <Card key={shelter.id} className="border-border">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-base">{shelter.name}</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="flex items-start gap-2 text-sm text-muted-foreground">
                      <MapPin className="h-4 w-4 text-primary shrink-0 mt-0.5" />
                      <span>{shelter.location.address}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <Users className="h-4 w-4 text-primary" />
                      <span>
                        {shelter.currentOccupancy} / {shelter.capacity} occupied
                      </span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <Phone className="h-4 w-4 text-primary" />
                      <a href={`tel:${shelter.contact}`} className="hover:text-primary">
                        {shelter.contact}
                      </a>
                    </div>
                    <div className="flex flex-wrap gap-1 pt-2">
                      {shelter.amenities.slice(0, 3).map((amenity, idx) => (
                        <span key={idx} className="text-xs px-2 py-1 rounded bg-primary/10 text-primary">
                          {amenity}
                        </span>
                      ))}
                    </div>
                    <Button className="w-full mt-2" size="sm">
                      <Navigation className="h-4 w-4 mr-2" />
                      Get Directions
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
