import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { User, Bell, MapPin, Save } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { storage } from "@/lib/storage";
import { disasterLabels } from "@/lib/disasterUtils";
import type { DisasterType } from "@/types";

export default function Profile() {
  const { toast } = useToast();
  const [user, setUser] = useState(storage.getUser());
  const [preferences, setPreferences] = useState(storage.getPreferences() || {
    userId: user?.id || '',
    alertTypes: [] as DisasterType[],
    notificationChannels: [] as ('email' | 'sms' | 'push')[],
    savedLocations: [],
    language: 'en',
  });

  const handleSave = () => {
    storage.setPreferences(preferences);
    toast({
      title: "Settings Saved",
      description: "Your preferences have been updated successfully.",
    });
  };

  const toggleAlertType = (type: DisasterType) => {
    const types = preferences.alertTypes.includes(type)
      ? preferences.alertTypes.filter(t => t !== type)
      : [...preferences.alertTypes, type];
    setPreferences({ ...preferences, alertTypes: types });
  };

  const toggleChannel = (channel: 'email' | 'sms' | 'push') => {
    const channels = preferences.notificationChannels.includes(channel)
      ? preferences.notificationChannels.filter(c => c !== channel)
      : [...preferences.notificationChannels, channel];
    setPreferences({ ...preferences, notificationChannels: channels });
  };

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="glass-card">
          <CardContent className="py-12 text-center">
            <User className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground">Please log in to view your profile</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold gradient-text mb-2">
            Profile Settings
          </h1>
          <p className="text-muted-foreground">
            Manage your account and notification preferences
          </p>
        </div>

        <div className="space-y-6">
          <Card className="glass-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <User className="h-5 w-5 text-primary" />
                Account Information
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Name</Label>
                <Input value={user.name} disabled />
              </div>
              <div className="space-y-2">
                <Label>Email</Label>
                <Input value={user.email} disabled />
              </div>
              <div className="space-y-2">
                <Label>Role</Label>
                <Input value={user.role.toUpperCase()} disabled />
              </div>
            </CardContent>
          </Card>

          <Card className="glass-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Bell className="h-5 w-5 text-primary" />
                Alert Preferences
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-3">
                <Label>Disaster Types to Monitor</Label>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {(Object.keys(disasterLabels) as DisasterType[]).map(type => (
                    <div key={type} className="flex items-center space-x-2">
                      <Checkbox
                        id={type}
                        checked={preferences.alertTypes.includes(type)}
                        onCheckedChange={() => toggleAlertType(type)}
                      />
                      <label
                        htmlFor={type}
                        className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer"
                      >
                        {disasterLabels[type]}
                      </label>
                    </div>
                  ))}
                </div>
              </div>

              <div className="space-y-3">
                <Label>Notification Channels</Label>
                <div className="space-y-2">
                  {(['email', 'sms', 'push'] as const).map(channel => (
                    <div key={channel} className="flex items-center space-x-2">
                      <Checkbox
                        id={channel}
                        checked={preferences.notificationChannels.includes(channel)}
                        onCheckedChange={() => toggleChannel(channel)}
                      />
                      <label
                        htmlFor={channel}
                        className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer"
                      >
                        {channel.toUpperCase()}
                      </label>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>

          <Button onClick={handleSave} size="lg" className="w-full">
            <Save className="h-4 w-4 mr-2" />
            Save Preferences
          </Button>
        </div>
      </div>
    </div>
  );
}
