import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Bell, BellOff, Clock, MapPin, AlertTriangle } from "lucide-react";
import type { Alert } from "@/types";
import { storage } from "@/lib/storage";
import { disasterLabels, severityColors, formatTimestamp } from "@/lib/disasterUtils";

export default function Alerts() {
  const [alerts, setAlerts] = useState<Alert[]>([]);

  useEffect(() => {
    const storedAlerts = storage.getAlerts();
    setAlerts(storedAlerts);
  }, []);

  const markAsRead = (alertId: string) => {
    const updatedAlerts = alerts.map(alert =>
      alert.id === alertId ? { ...alert, isRead: true } : alert
    );
    setAlerts(updatedAlerts);
    storage.setAlerts(updatedAlerts);
  };

  const markAllAsRead = () => {
    const updatedAlerts = alerts.map(alert => ({ ...alert, isRead: true }));
    setAlerts(updatedAlerts);
    storage.setAlerts(updatedAlerts);
  };

  const activeAlerts = alerts.filter(a => !a.isRead);
  const readAlerts = alerts.filter(a => a.isRead);

  const AlertCard = ({ alert }: { alert: Alert }) => (
    <Card className={`glass-card ${!alert.isRead ? 'border-primary' : ''}`}>
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between gap-2">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-2">
              <Badge 
                variant="outline" 
                className="text-xs"
                style={{ 
                  borderColor: severityColors[alert.severity],
                  color: severityColors[alert.severity]
                }}
              >
                {disasterLabels[alert.type]}
              </Badge>
              <Badge 
                variant="outline" 
                className="text-xs font-semibold"
                style={{ 
                  borderColor: severityColors[alert.severity],
                  color: severityColors[alert.severity],
                  backgroundColor: `${severityColors[alert.severity]}15`
                }}
              >
                {alert.severity.toUpperCase()}
              </Badge>
              {!alert.isRead && (
                <Badge variant="default" className="text-xs">
                  New
                </Badge>
              )}
            </div>
            <CardTitle className="text-lg">{alert.title}</CardTitle>
          </div>
          {!alert.isRead && (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => markAsRead(alert.id)}
            >
              <BellOff className="h-4 w-4" />
            </Button>
          )}
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        <p className="text-sm text-muted-foreground">{alert.message}</p>
        <div className="space-y-2">
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <MapPin className="h-3 w-3 text-primary" />
            <span>{alert.location}</span>
          </div>
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <Clock className="h-3 w-3 text-primary" />
            <span>{formatTimestamp(alert.timestamp)}</span>
          </div>
        </div>
        <div className="flex flex-wrap gap-2 pt-2">
          {alert.channels.map(channel => (
            <Badge key={channel} variant="secondary" className="text-xs">
              {channel.toUpperCase()}
            </Badge>
          ))}
        </div>
      </CardContent>
    </Card>
  );

  return (
    <div className="min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8 flex items-center justify-between">
          <div>
            <h1 className="text-4xl font-bold gradient-text mb-2">
              Disaster Alerts
            </h1>
            <p className="text-muted-foreground">
              Real-time notifications and alert history
            </p>
          </div>
          {activeAlerts.length > 0 && (
            <Button onClick={markAllAsRead} variant="outline">
              Mark All as Read
            </Button>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          <Card className="glass-card">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <Bell className="h-4 w-4 text-primary" />
                Active Alerts
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-primary">{activeAlerts.length}</div>
            </CardContent>
          </Card>

          <Card className="glass-card">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <AlertTriangle className="h-4 w-4 text-destructive" />
                Critical Alerts
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-destructive">
                {alerts.filter(a => a.severity === 'critical').length}
              </div>
            </CardContent>
          </Card>

          <Card className="glass-card">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <Clock className="h-4 w-4 text-secondary" />
                Total Alerts
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-secondary">{alerts.length}</div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="active" className="space-y-6">
          <TabsList className="glass-card">
            <TabsTrigger value="active">
              Active ({activeAlerts.length})
            </TabsTrigger>
            <TabsTrigger value="history">
              History ({readAlerts.length})
            </TabsTrigger>
          </TabsList>

          <TabsContent value="active" className="space-y-4">
            {activeAlerts.length === 0 ? (
              <Card className="glass-card">
                <CardContent className="py-12 text-center">
                  <Bell className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <p className="text-muted-foreground">No active alerts at the moment</p>
                </CardContent>
              </Card>
            ) : (
              activeAlerts.map(alert => <AlertCard key={alert.id} alert={alert} />)
            )}
          </TabsContent>

          <TabsContent value="history" className="space-y-4">
            {readAlerts.length === 0 ? (
              <Card className="glass-card">
                <CardContent className="py-12 text-center">
                  <Clock className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <p className="text-muted-foreground">No alert history</p>
                </CardContent>
              </Card>
            ) : (
              readAlerts.map(alert => <AlertCard key={alert.id} alert={alert} />)
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
