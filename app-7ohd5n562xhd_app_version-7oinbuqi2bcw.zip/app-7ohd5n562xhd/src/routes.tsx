import type { ReactNode } from 'react';
import Home from './pages/Home';
import Analytics from './pages/Analytics';
import Alerts from './pages/Alerts';
import Resources from './pages/Resources';
import Encyclopedia from './pages/Encyclopedia';
import Report from './pages/Report';
import Login from './pages/Login';
import Profile from './pages/Profile';
import Admin from './pages/Admin';
import NotFound from './pages/NotFound';

interface RouteConfig {
  name: string;
  path: string;
  element: ReactNode;
  visible?: boolean;
}

const routes: RouteConfig[] = [
  {
    name: 'Home',
    path: '/',
    element: <Home />
  },
  {
    name: 'Analytics',
    path: '/analytics',
    element: <Analytics />
  },
  {
    name: 'Alerts',
    path: '/alerts',
    element: <Alerts />
  },
  {
    name: 'Resources',
    path: '/resources',
    element: <Resources />
  },
  {
    name: 'Encyclopedia',
    path: '/encyclopedia',
    element: <Encyclopedia />
  },
  {
    name: 'Report Disaster',
    path: '/report',
    element: <Report />
  },
  {
    name: 'Login',
    path: '/login',
    element: <Login />,
    visible: false
  },
  {
    name: 'Profile',
    path: '/profile',
    element: <Profile />,
    visible: false
  },
  {
    name: 'Admin',
    path: '/admin',
    element: <Admin />,
    visible: false
  },
  {
    name: 'Not Found',
    path: '*',
    element: <NotFound />,
    visible: false
  }
];

export default routes;