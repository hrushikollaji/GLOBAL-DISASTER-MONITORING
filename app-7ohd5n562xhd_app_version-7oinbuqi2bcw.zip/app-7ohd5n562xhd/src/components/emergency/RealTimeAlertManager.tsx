import { useState, useEffect } from 'react';
import { FloatingAlert } from './FloatingAlert';
import { fetchEarthquakes, fetchWildfires, fetchCyclones } from '@/lib/disasterApis';

interface Alert {
  id: string;
  type: 'earthquake' | 'wildfire' | 'cyclone';
  severity: 'critical' | 'high' | 'moderate';
  title: string;
  message: string;
  location: string;
}

export function RealTimeAlertManager() {
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [lastCheck, setLastCheck] = useState<Date>(new Date());
  const [seenIds, setSeenIds] = useState<Set<string>>(new Set());

  useEffect(() => {
    const checkForNewAlerts = async () => {
      try {
        const [earthquakes, wildfires, cyclones] = await Promise.all([
          fetchEarthquakes(),
          fetchWildfires(),
          fetchCyclones(),
        ]);

        const newAlerts: Alert[] = [];

        // Check for critical earthquakes
        earthquakes
          .filter(eq => eq.magnitude >= 6.0 && !seenIds.has(eq.id))
          .slice(0, 3)
          .forEach(eq => {
            newAlerts.push({
              id: eq.id,
              type: 'earthquake',
              severity: eq.magnitude >= 7 ? 'critical' : 'high',
              title: `M${eq.magnitude.toFixed(1)} Earthquake Detected`,
              message: `Depth: ${eq.depth.toFixed(1)} km. Take immediate safety precautions.`,
              location: eq.location,
            });
            seenIds.add(eq.id);
          });

        // Check for high-intensity wildfires
        wildfires
          .filter(fire => fire.brightness >= 400 && !seenIds.has(fire.id))
          .slice(0, 2)
          .forEach(fire => {
            newAlerts.push({
              id: fire.id,
              type: 'wildfire',
              severity: fire.brightness >= 450 ? 'critical' : 'high',
              title: 'High-Intensity Wildfire',
              message: `Brightness: ${fire.brightness.toFixed(0)}K. Evacuate if in affected area.`,
              location: `${fire.latitude.toFixed(2)}°N, ${fire.longitude.toFixed(2)}°E`,
            });
            seenIds.add(fire.id);
          });

        // Check for active cyclones
        cyclones
          .filter(cyclone => !seenIds.has(cyclone.id))
          .slice(0, 2)
          .forEach(cyclone => {
            newAlerts.push({
              id: cyclone.id,
              type: 'cyclone',
              severity: cyclone.windSpeed > 130 ? 'critical' : 'high',
              title: `Cyclone ${cyclone.name}`,
              message: `Wind: ${cyclone.windSpeed} km/h. Seek shelter immediately.`,
              location: `${cyclone.latitude.toFixed(2)}°N, ${cyclone.longitude.toFixed(2)}°E`,
            });
            seenIds.add(cyclone.id);
          });

        if (newAlerts.length > 0) {
          setAlerts(prev => [...newAlerts, ...prev].slice(0, 5));
          
          // Play alert sound for critical alerts
          if (newAlerts.some(a => a.severity === 'critical')) {
            playAlertSound();
          }
        }

        setLastCheck(new Date());
        setSeenIds(new Set(seenIds));
      } catch (error) {
        console.error('Error checking for new alerts:', error);
      }
    };

    // Initial check
    checkForNewAlerts();

    // Check every 2 minutes
    const interval = setInterval(checkForNewAlerts, 2 * 60 * 1000);

    return () => clearInterval(interval);
  }, []);

  const playAlertSound = () => {
    // Create a simple beep sound using Web Audio API
    try {
      const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
      const oscillator = audioContext.createOscillator();
      const gainNode = audioContext.createGain();

      oscillator.connect(gainNode);
      gainNode.connect(audioContext.destination);

      oscillator.frequency.value = 800;
      oscillator.type = 'sine';

      gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.5);

      oscillator.start(audioContext.currentTime);
      oscillator.stop(audioContext.currentTime + 0.5);
    } catch (error) {
      console.error('Error playing alert sound:', error);
    }
  };

  const handleDismiss = (id: string) => {
    setAlerts(prev => prev.filter(alert => alert.id !== id));
  };

  return (
    <>
      {alerts.map((alert, index) => (
        <div
          key={alert.id}
          style={{
            position: 'fixed',
            top: `${80 + index * 120}px`,
            right: '1rem',
            zIndex: 50 - index,
          }}
        >
          <FloatingAlert
            type={alert.type}
            severity={alert.severity}
            title={alert.title}
            message={alert.message}
            location={alert.location}
            onDismiss={() => handleDismiss(alert.id)}
            autoHide={true}
            duration={15000}
          />
        </div>
      ))}
    </>
  );
}
