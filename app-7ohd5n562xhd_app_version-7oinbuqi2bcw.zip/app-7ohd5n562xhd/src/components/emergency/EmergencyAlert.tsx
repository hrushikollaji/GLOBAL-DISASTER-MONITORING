import { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { AlertTriangle, Phone, X, Bell, MapPin } from 'lucide-react';

interface EmergencyAlertProps {
  title: string;
  message: string;
  severity: 'critical' | 'high' | 'moderate';
  location: string;
  onDismiss?: () => void;
  emergencyNumbers?: string[];
}

export function EmergencyAlert({
  title,
  message,
  severity,
  location,
  onDismiss,
  emergencyNumbers = ['911', '112'],
}: EmergencyAlertProps) {
  const [isVisible, setIsVisible] = useState(true);
  const [isPulsing, setIsPulsing] = useState(true);

  useEffect(() => {
    if (severity === 'critical') {
      const pulseInterval = setInterval(() => {
        setIsPulsing(prev => !prev);
      }, 1000);
      return () => clearInterval(pulseInterval);
    }
  }, [severity]);

  const handleDismiss = () => {
    setIsVisible(false);
    onDismiss?.();
  };

  const handleCall = (number: string) => {
    window.location.href = `tel:${number}`;
  };

  if (!isVisible) return null;

  const severityConfig = {
    critical: {
      bg: 'bg-red-500/10 border-red-500',
      text: 'text-red-500',
      icon: 'text-red-500',
      badge: 'bg-red-500',
    },
    high: {
      bg: 'bg-orange-500/10 border-orange-500',
      text: 'text-orange-500',
      icon: 'text-orange-500',
      badge: 'bg-orange-500',
    },
    moderate: {
      bg: 'bg-yellow-500/10 border-yellow-500',
      text: 'text-yellow-500',
      icon: 'text-yellow-500',
      badge: 'bg-yellow-500',
    },
  };

  const config = severityConfig[severity];

  return (
    <Card 
      className={`${config.bg} border-2 transition-all duration-300 ${
        isPulsing && severity === 'critical' ? 'scale-[1.02] shadow-lg shadow-red-500/20' : ''
      }`}
    >
      <CardContent className="p-4 sm:p-6">
        <div className="flex items-start gap-3 sm:gap-4">
          <div className={`p-2 sm:p-3 rounded-full ${config.bg} ${isPulsing && severity === 'critical' ? 'animate-pulse' : ''}`}>
            <AlertTriangle className={`h-5 w-5 sm:h-6 sm:w-6 ${config.icon}`} />
          </div>
          
          <div className="flex-1 space-y-3">
            <div className="flex items-start justify-between gap-2">
              <div className="space-y-1">
                <div className="flex items-center gap-2 flex-wrap">
                  <Badge className={`${config.badge} text-white text-xs`}>
                    {severity.toUpperCase()}
                  </Badge>
                  <h3 className={`font-bold text-base sm:text-lg ${config.text}`}>
                    {title}
                  </h3>
                </div>
                <div className="flex items-center gap-1 text-xs sm:text-sm text-muted-foreground">
                  <MapPin className="h-3 w-3 sm:h-4 sm:w-4" />
                  <span>{location}</span>
                </div>
              </div>
              
              <Button
                variant="ghost"
                size="icon"
                onClick={handleDismiss}
                className="h-6 w-6 sm:h-8 sm:w-8 shrink-0"
              >
                <X className="h-4 w-4" />
              </Button>
            </div>

            <p className="text-sm sm:text-base text-foreground/90">
              {message}
            </p>

            <div className="flex flex-col sm:flex-row gap-2 sm:gap-3 pt-2">
              {emergencyNumbers.map((number) => (
                <Button
                  key={number}
                  onClick={() => handleCall(number)}
                  className={`gap-2 ${config.bg} ${config.text} hover:opacity-80 transition-all w-full sm:w-auto`}
                  variant="outline"
                >
                  <Phone className="h-4 w-4" />
                  <span className="font-semibold">Call {number}</span>
                </Button>
              ))}
              <Button
                variant="outline"
                className="gap-2 w-full sm:w-auto"
              >
                <Bell className="h-4 w-4" />
                <span>Get Updates</span>
              </Button>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
