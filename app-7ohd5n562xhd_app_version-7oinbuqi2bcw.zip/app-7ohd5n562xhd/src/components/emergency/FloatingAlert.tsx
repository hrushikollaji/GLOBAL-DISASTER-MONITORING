import { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { X, Phone, AlertTriangle, Flame, Activity, Waves } from 'lucide-react';

interface FloatingAlertProps {
  type: 'earthquake' | 'wildfire' | 'cyclone';
  severity: 'critical' | 'high' | 'moderate';
  title: string;
  message: string;
  location: string;
  onDismiss?: () => void;
  autoHide?: boolean;
  duration?: number;
}

export function FloatingAlert({
  type,
  severity,
  title,
  message,
  location,
  onDismiss,
  autoHide = true,
  duration = 10000,
}: FloatingAlertProps) {
  const [isVisible, setIsVisible] = useState(true);
  const [progress, setProgress] = useState(100);

  useEffect(() => {
    if (autoHide) {
      const startTime = Date.now();
      const interval = setInterval(() => {
        const elapsed = Date.now() - startTime;
        const remaining = Math.max(0, 100 - (elapsed / duration) * 100);
        setProgress(remaining);

        if (remaining === 0) {
          handleDismiss();
        }
      }, 50);

      return () => clearInterval(interval);
    }
  }, [autoHide, duration]);

  const handleDismiss = () => {
    setIsVisible(false);
    onDismiss?.();
  };

  const handleCall = () => {
    window.location.href = 'tel:911';
  };

  if (!isVisible) return null;

  const config = {
    earthquake: {
      icon: <Activity className="h-5 w-5" />,
      color: 'text-red-500',
      bg: 'bg-red-500/10',
      border: 'border-red-500',
      gradient: 'from-red-500/20 to-transparent',
    },
    wildfire: {
      icon: <Flame className="h-5 w-5" />,
      color: 'text-orange-500',
      bg: 'bg-orange-500/10',
      border: 'border-orange-500',
      gradient: 'from-orange-500/20 to-transparent',
    },
    cyclone: {
      icon: <Waves className="h-5 w-5" />,
      color: 'text-cyan-500',
      bg: 'bg-cyan-500/10',
      border: 'border-cyan-500',
      gradient: 'from-cyan-500/20 to-transparent',
    },
  };

  const severityBadge = {
    critical: 'bg-red-500',
    high: 'bg-orange-500',
    moderate: 'bg-yellow-500',
  };

  const typeConfig = config[type];

  return (
    <Card
      className={`fixed top-20 right-4 w-[90vw] sm:w-96 shadow-2xl border-2 ${typeConfig.border} ${typeConfig.bg} animate-in slide-in-from-right-5 duration-500 z-50`}
    >
      <div className={`absolute inset-0 bg-gradient-to-r ${typeConfig.gradient} rounded-lg pointer-events-none`} />
      
      <CardContent className="p-4 relative">
        <div className="flex items-start gap-3">
          <div className={`p-2 rounded-full ${typeConfig.bg} ${severity === 'critical' ? 'animate-pulse' : ''}`}>
            {typeConfig.icon}
          </div>

          <div className="flex-1 min-w-0">
            <div className="flex items-start justify-between gap-2 mb-2">
              <div className="flex items-center gap-2 flex-wrap">
                <Badge className={`${severityBadge[severity]} text-white text-xs`}>
                  {severity.toUpperCase()}
                </Badge>
                <h3 className={`font-bold text-sm ${typeConfig.color}`}>
                  {title}
                </h3>
              </div>
              <Button
                variant="ghost"
                size="icon"
                onClick={handleDismiss}
                className="h-6 w-6 shrink-0"
              >
                <X className="h-4 w-4" />
              </Button>
            </div>

            <p className="text-sm text-foreground/90 mb-2">{message}</p>
            <p className="text-xs text-muted-foreground mb-3">📍 {location}</p>

            <div className="flex gap-2">
              <Button
                onClick={handleCall}
                size="sm"
                className={`gap-2 ${typeConfig.bg} ${typeConfig.color} hover:opacity-80 flex-1`}
                variant="outline"
              >
                <Phone className="h-3 w-3" />
                Call 911
              </Button>
              <Button
                onClick={handleDismiss}
                size="sm"
                variant="outline"
                className="flex-1"
              >
                Dismiss
              </Button>
            </div>
          </div>
        </div>

        {autoHide && (
          <div className="absolute bottom-0 left-0 right-0 h-1 bg-border rounded-b-lg overflow-hidden">
            <div
              className={`h-full bg-gradient-to-r ${typeConfig.gradient} transition-all duration-100`}
              style={{ width: `${progress}%` }}
            />
          </div>
        )}
      </CardContent>
    </Card>
  );
}
