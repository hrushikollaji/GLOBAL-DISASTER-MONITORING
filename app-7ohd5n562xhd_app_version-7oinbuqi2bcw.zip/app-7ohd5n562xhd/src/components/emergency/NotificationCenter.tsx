import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Bell, X, AlertTriangle, Flame, Waves, Activity, Phone } from 'lucide-react';
import { fetchEarthquakes, fetchWildfires, fetchCyclones } from '@/lib/disasterApis';

interface Notification {
  id: string;
  type: 'earthquake' | 'wildfire' | 'cyclone';
  severity: 'critical' | 'high' | 'moderate' | 'low';
  title: string;
  message: string;
  location: string;
  timestamp: Date;
  isRead: boolean;
}

export function NotificationCenter() {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [isOpen, setIsOpen] = useState(false);
  const [unreadCount, setUnreadCount] = useState(0);

  useEffect(() => {
    const checkForNewDisasters = async () => {
      try {
        const [earthquakes, wildfires, cyclones] = await Promise.all([
          fetchEarthquakes(),
          fetchWildfires(),
          fetchCyclones(),
        ]);

        const newNotifications: Notification[] = [];

        // Critical earthquakes
        earthquakes
          .filter(eq => eq.magnitude >= 5.5)
          .slice(0, 5)
          .forEach(eq => {
            newNotifications.push({
              id: eq.id,
              type: 'earthquake',
              severity: eq.magnitude >= 7 ? 'critical' : 'high',
              title: `M${eq.magnitude.toFixed(1)} Earthquake`,
              message: `Detected at depth ${eq.depth.toFixed(1)} km`,
              location: eq.location,
              timestamp: new Date(eq.time),
              isRead: false,
            });
          });

        // High-intensity wildfires
        wildfires
          .filter(fire => fire.brightness >= 380)
          .slice(0, 5)
          .forEach(fire => {
            newNotifications.push({
              id: fire.id,
              type: 'wildfire',
              severity: fire.brightness >= 400 ? 'high' : 'moderate',
              title: 'Active Wildfire',
              message: `Brightness: ${fire.brightness.toFixed(0)}K, Confidence: ${fire.confidence.toFixed(0)}%`,
              location: `${fire.latitude.toFixed(2)}°, ${fire.longitude.toFixed(2)}°`,
              timestamp: new Date(),
              isRead: false,
            });
          });

        // Active cyclones
        cyclones.slice(0, 5).forEach(cyclone => {
          newNotifications.push({
            id: cyclone.id,
            type: 'cyclone',
            severity: cyclone.windSpeed > 130 ? 'critical' : 'high',
            title: cyclone.name,
            message: `Wind: ${cyclone.windSpeed} km/h, ${cyclone.category}`,
            location: `${cyclone.latitude.toFixed(2)}°, ${cyclone.longitude.toFixed(2)}°`,
            timestamp: new Date(cyclone.time),
            isRead: false,
          });
        });

        // Sort by severity and timestamp
        newNotifications.sort((a, b) => {
          const severityOrder = { critical: 0, high: 1, moderate: 2, low: 3 };
          if (severityOrder[a.severity] !== severityOrder[b.severity]) {
            return severityOrder[a.severity] - severityOrder[b.severity];
          }
          return b.timestamp.getTime() - a.timestamp.getTime();
        });

        setNotifications(newNotifications);
        setUnreadCount(newNotifications.filter(n => !n.isRead).length);
      } catch (error) {
        console.error('Error fetching notifications:', error);
      }
    };

    checkForNewDisasters();
    const interval = setInterval(checkForNewDisasters, 2 * 60 * 1000); // Every 2 minutes

    return () => clearInterval(interval);
  }, []);

  const markAsRead = (id: string) => {
    setNotifications(prev =>
      prev.map(n => (n.id === id ? { ...n, isRead: true } : n))
    );
    setUnreadCount(prev => Math.max(0, prev - 1));
  };

  const markAllAsRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, isRead: true })));
    setUnreadCount(0);
  };

  const getIcon = (type: string) => {
    switch (type) {
      case 'earthquake':
        return <Activity className="h-4 w-4" />;
      case 'wildfire':
        return <Flame className="h-4 w-4" />;
      case 'cyclone':
        return <Waves className="h-4 w-4" />;
      default:
        return <AlertTriangle className="h-4 w-4" />;
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical':
        return 'bg-red-500/10 border-red-500 text-red-500';
      case 'high':
        return 'bg-orange-500/10 border-orange-500 text-orange-500';
      case 'moderate':
        return 'bg-yellow-500/10 border-yellow-500 text-yellow-500';
      default:
        return 'bg-blue-500/10 border-blue-500 text-blue-500';
    }
  };

  const handleEmergencyCall = () => {
    window.location.href = 'tel:911';
  };

  return (
    <div className="fixed bottom-4 right-4 z-50">
      {/* Notification Bell Button */}
      <Button
        onClick={() => setIsOpen(!isOpen)}
        className="relative h-14 w-14 rounded-full shadow-lg hover:scale-110 transition-all bg-primary"
        size="icon"
      >
        <Bell className="h-6 w-6" />
        {unreadCount > 0 && (
          <Badge
            variant="destructive"
            className="absolute -top-1 -right-1 h-6 w-6 flex items-center justify-center p-0 text-xs animate-pulse"
          >
            {unreadCount > 9 ? '9+' : unreadCount}
          </Badge>
        )}
      </Button>

      {/* Notification Panel */}
      {isOpen && (
        <Card className="absolute bottom-20 right-0 w-[90vw] sm:w-96 max-h-[70vh] shadow-2xl animate-in slide-in-from-bottom-5 duration-300">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg flex items-center gap-2">
                <Bell className="h-5 w-5 text-primary" />
                Disaster Alerts
              </CardTitle>
              <div className="flex items-center gap-2">
                {unreadCount > 0 && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={markAllAsRead}
                    className="text-xs"
                  >
                    Mark all read
                  </Button>
                )}
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setIsOpen(false)}
                  className="h-8 w-8"
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
            </div>
            <div className="flex items-center gap-2 mt-2">
              <Badge variant="outline" className="text-xs">
                {notifications.length} Active
              </Badge>
              <Badge variant="destructive" className="text-xs">
                {unreadCount} Unread
              </Badge>
            </div>
          </CardHeader>

          <ScrollArea className="h-[50vh]">
            <CardContent className="space-y-2 pt-0">
              {notifications.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <Bell className="h-12 w-12 mx-auto mb-2 opacity-50" />
                  <p className="text-sm">No active alerts</p>
                </div>
              ) : (
                notifications.map((notification) => (
                  <div
                    key={notification.id}
                    className={`p-3 rounded-lg border-2 transition-all cursor-pointer hover:scale-[1.02] ${
                      getSeverityColor(notification.severity)
                    } ${notification.isRead ? 'opacity-60' : 'animate-pulse-glow'}`}
                    onClick={() => markAsRead(notification.id)}
                  >
                    <div className="flex items-start gap-3">
                      <div className={`p-2 rounded-full ${getSeverityColor(notification.severity)}`}>
                        {getIcon(notification.type)}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between gap-2 mb-1">
                          <h4 className="font-semibold text-sm truncate">
                            {notification.title}
                          </h4>
                          {!notification.isRead && (
                            <div className="h-2 w-2 rounded-full bg-primary shrink-0 mt-1" />
                          )}
                        </div>
                        <p className="text-xs text-muted-foreground mb-1">
                          {notification.message}
                        </p>
                        <p className="text-xs text-muted-foreground truncate">
                          📍 {notification.location}
                        </p>
                        <p className="text-xs text-muted-foreground mt-1">
                          {notification.timestamp.toLocaleTimeString()}
                        </p>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </CardContent>
          </ScrollArea>

          {notifications.length > 0 && (
            <div className="p-4 border-t border-border">
              <Button
                onClick={handleEmergencyCall}
                className="w-full gap-2 bg-red-500 hover:bg-red-600 text-white"
              >
                <Phone className="h-4 w-4" />
                Emergency Call 911
              </Button>
            </div>
          )}
        </Card>
      )}
    </div>
  );
}
