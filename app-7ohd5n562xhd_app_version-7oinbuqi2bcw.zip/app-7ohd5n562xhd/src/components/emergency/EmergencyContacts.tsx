import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Phone, Shield, Ambulance, Flame, Waves, AlertTriangle } from 'lucide-react';

interface EmergencyContact {
  name: string;
  number: string;
  icon: React.ReactNode;
  description: string;
  color: string;
}

export function EmergencyContacts() {
  const contacts: EmergencyContact[] = [
    {
      name: 'Emergency Services',
      number: '911',
      icon: <Shield className="h-5 w-5" />,
      description: 'Police, Fire, Medical',
      color: 'text-red-500 bg-red-500/10 border-red-500/30',
    },
    {
      name: 'International Emergency',
      number: '112',
      icon: <AlertTriangle className="h-5 w-5" />,
      description: 'Global Emergency Number',
      color: 'text-orange-500 bg-orange-500/10 border-orange-500/30',
    },
    {
      name: 'Ambulance',
      number: '102',
      icon: <Ambulance className="h-5 w-5" />,
      description: 'Medical Emergency',
      color: 'text-blue-500 bg-blue-500/10 border-blue-500/30',
    },
    {
      name: 'Fire Department',
      number: '101',
      icon: <Flame className="h-5 w-5" />,
      description: 'Fire & Rescue',
      color: 'text-orange-600 bg-orange-600/10 border-orange-600/30',
    },
    {
      name: 'Disaster Management',
      number: '1078',
      icon: <Waves className="h-5 w-5" />,
      description: 'Natural Disasters',
      color: 'text-cyan-500 bg-cyan-500/10 border-cyan-500/30',
    },
    {
      name: 'National Helpline',
      number: '1800-180-1104',
      icon: <Phone className="h-5 w-5" />,
      description: 'Disaster Helpline',
      color: 'text-purple-500 bg-purple-500/10 border-purple-500/30',
    },
  ];

  const handleCall = (number: string) => {
    window.location.href = `tel:${number}`;
  };

  return (
    <Card className="glass-card">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Phone className="h-5 w-5 text-primary" />
          Emergency Contacts
        </CardTitle>
        <p className="text-sm text-muted-foreground">
          Click to call emergency services instantly
        </p>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {contacts.map((contact) => (
            <Button
              key={contact.number}
              onClick={() => handleCall(contact.number)}
              variant="outline"
              className={`h-auto p-4 flex flex-col items-start gap-2 hover:scale-105 transition-all border-2 ${contact.color}`}
            >
              <div className="flex items-center gap-2 w-full">
                <div className={`p-2 rounded-lg ${contact.color}`}>
                  {contact.icon}
                </div>
                <div className="flex-1 text-left">
                  <div className="font-semibold text-sm">{contact.name}</div>
                  <div className="text-xs text-muted-foreground">
                    {contact.description}
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-2 w-full justify-between">
                <span className="text-lg font-bold">{contact.number}</span>
                <Phone className="h-4 w-4" />
              </div>
            </Button>
          ))}
        </div>

        <div className="mt-4 p-4 rounded-lg bg-muted/50 border border-border">
          <p className="text-xs text-muted-foreground">
            <strong>Note:</strong> Emergency numbers may vary by country. The numbers shown are for reference. 
            Always use your local emergency numbers in case of an actual emergency.
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
