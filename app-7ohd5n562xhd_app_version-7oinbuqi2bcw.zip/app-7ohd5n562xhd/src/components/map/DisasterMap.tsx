import { useEffect, useRef, useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Loader2, RefreshCw, MapPin, Flame, Wind, Activity } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { 
  fetchEarthquakes, 
  fetchWildfires,
  fetchCyclones,
  getSeverityColor,
  getRiskLevel,
  type EarthquakeData,
  type WildfireData,
  type CycloneData
} from '@/lib/disasterApis';

declare global {
  interface Window {
    L: any;
  }
}

export function DisasterMap() {
  const mapRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<any>(null);
  const markersRef = useRef<any[]>([]);
  const markerClusterGroupRef = useRef<any>(null);
  const { toast } = useToast();
  
  const [loading, setLoading] = useState(true);
  const [loadingType, setLoadingType] = useState<string>('');
  const [earthquakes, setEarthquakes] = useState<EarthquakeData[]>([]);
  const [wildfires, setWildfires] = useState<WildfireData[]>([]);
  const [cyclones, setCyclones] = useState<CycloneData[]>([]);
  const [lastUpdate, setLastUpdate] = useState<Date>(new Date());
  const [activeFilters, setActiveFilters] = useState({
    earthquakes: true,
    wildfires: true,
    cyclones: true,
  });
  const [stats, setStats] = useState({
    earthquakes: 0,
    wildfires: 0,
    cyclones: 0,
    critical: 0,
  });

  // Initialize Leaflet map
  useEffect(() => {
    if (!mapRef.current || mapInstanceRef.current) return;

    // Wait for Leaflet to load
    const initMap = () => {
      if (typeof window.L === 'undefined') {
        setTimeout(initMap, 100);
        return;
      }

      const L = window.L;

      // Create map
      const map = L.map(mapRef.current, {
        center: [20, 0],
        zoom: 2,
        minZoom: 2,
        maxZoom: 18,
      });

      // Add dark tile layer
      L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>',
        subdomains: 'abcd',
        maxZoom: 20
      }).addTo(map);

      // Initialize marker cluster group
      if (L.markerClusterGroup) {
        markerClusterGroupRef.current = L.markerClusterGroup({
          maxClusterRadius: 50,
          spiderfyOnMaxZoom: true,
          showCoverageOnHover: false,
          zoomToBoundsOnClick: true,
        });
        map.addLayer(markerClusterGroupRef.current);
      }

      mapInstanceRef.current = map;
      setLoading(false);
    };

    initMap();

    return () => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove();
        mapInstanceRef.current = null;
      }
    };
  }, []);

  // Fetch real-time data
  const loadDisasterData = async () => {
    setLoading(true);
    setLoadingType('all');
    try {
      const [earthquakeData, wildfireData, cycloneData] = await Promise.all([
        fetchEarthquakes(),
        fetchWildfires(),
        fetchCyclones(),
      ]);

      setEarthquakes(earthquakeData);
      setWildfires(wildfireData);
      setCyclones(cycloneData);
      setLastUpdate(new Date());

      // Calculate stats
      const criticalEarthquakes = earthquakeData.filter(e => e.magnitude >= 5.5).length;
      const criticalCyclones = cycloneData.filter(c => c.windSpeed > 130).length;
      
      setStats({
        earthquakes: earthquakeData.length,
        wildfires: wildfireData.length,
        cyclones: cycloneData.length,
        critical: criticalEarthquakes + criticalCyclones,
      });

      toast({
        title: "Data Updated",
        description: `Loaded ${earthquakeData.length} earthquakes, ${wildfireData.length} wildfires, ${cycloneData.length} cyclones`,
      });
    } catch (error) {
      console.error('Error loading disaster data:', error);
      toast({
        title: "Error",
        description: "Failed to load some disaster data. Check console for details.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
      setLoadingType('');
    }
  };

  // Load specific disaster type
  const loadSpecificData = async (type: 'earthquakes' | 'wildfires' | 'cyclones') => {
    setLoadingType(type);
    try {
      if (type === 'earthquakes') {
        const data = await fetchEarthquakes();
        setEarthquakes(data);
        toast({
          title: "Earthquakes Updated",
          description: `Loaded ${data.length} earthquakes from USGS`,
        });
      } else if (type === 'wildfires') {
        const data = await fetchWildfires();
        setWildfires(data);
        toast({
          title: "Wildfires Updated",
          description: `Loaded ${data.length} active fires from NASA FIRMS`,
        });
      } else if (type === 'cyclones') {
        const data = await fetchCyclones();
        setCyclones(data);
        toast({
          title: "Cyclones Updated",
          description: `Loaded ${data.length} active cyclones from GDACS`,
        });
      }
      setLastUpdate(new Date());
    } catch (error) {
      console.error(`Error loading ${type}:`, error);
      toast({
        title: "Error",
        description: `Failed to load ${type}. Check console for details.`,
        variant: "destructive",
      });
    } finally {
      setLoadingType('');
    }
  };

  // Update markers on map
  useEffect(() => {
    if (!mapInstanceRef.current || typeof window.L === 'undefined') return;

    const L = window.L;

    // Clear existing markers
    if (markerClusterGroupRef.current) {
      markerClusterGroupRef.current.clearLayers();
    }
    markersRef.current.forEach(marker => marker.remove());
    markersRef.current = [];

    // Add earthquake markers
    if (activeFilters.earthquakes) {
      earthquakes.forEach(eq => {
        const color = getSeverityColor(eq.magnitude, 'earthquake');
        const riskLevel = getRiskLevel(eq.magnitude, 'earthquake');
        
        const marker = L.circleMarker([eq.latitude, eq.longitude], {
          radius: Math.max(4, eq.magnitude * 2),
          fillColor: color,
          color: '#fff',
          weight: 2,
          opacity: 1,
          fillOpacity: 0.7,
        });

        const popupContent = `
          <div style="color: #000; min-width: 200px;">
            <h3 style="font-weight: bold; margin-bottom: 8px; color: ${color};">
              🌍 Earthquake - M${eq.magnitude.toFixed(1)}
            </h3>
            <p style="font-size: 12px; margin-bottom: 4px;">
              <strong>Location:</strong> ${eq.location}
            </p>
            <p style="font-size: 12px; margin-bottom: 4px;">
              <strong>Depth:</strong> ${eq.depth.toFixed(1)} km
            </p>
            <p style="font-size: 12px; margin-bottom: 4px;">
              <strong>Time:</strong> ${new Date(eq.time).toLocaleString()}
            </p>
            <p style="font-size: 12px; margin-bottom: 8px;">
              <strong>Risk Level:</strong> <span style="color: ${color}; font-weight: bold;">${riskLevel}</span>
            </p>
            <a href="${eq.url}" target="_blank" style="display: inline-block; padding: 4px 12px; background: ${color}; color: white; text-decoration: none; border-radius: 4px; font-size: 12px;">
              Check Risk Details
            </a>
          </div>
        `;

        marker.bindPopup(popupContent);

        if (markerClusterGroupRef.current) {
          markerClusterGroupRef.current.addLayer(marker);
        } else {
          marker.addTo(mapInstanceRef.current);
        }
        
        markersRef.current.push(marker);
      });
    }

    // Add wildfire markers
    if (activeFilters.wildfires) {
      wildfires.forEach(fire => {
        const color = getSeverityColor(fire.brightness, 'fire');
        const riskLevel = getRiskLevel(fire.brightness, 'fire');
        
        const marker = L.circleMarker([fire.latitude, fire.longitude], {
          radius: 6,
          fillColor: color,
          color: '#fff',
          weight: 2,
          opacity: 1,
          fillOpacity: 0.8,
        });

        const popupContent = `
          <div style="color: #000; min-width: 200px;">
            <h3 style="font-weight: bold; margin-bottom: 8px; color: ${color};">
              🔥 Wildfire
            </h3>
            <p style="font-size: 12px; margin-bottom: 4px;">
              <strong>Brightness:</strong> ${fire.brightness.toFixed(1)} K
            </p>
            <p style="font-size: 12px; margin-bottom: 4px;">
              <strong>Confidence:</strong> ${fire.confidence.toFixed(0)}%
            </p>
            <p style="font-size: 12px; margin-bottom: 4px;">
              <strong>Time:</strong> ${fire.time}
            </p>
            <p style="font-size: 12px; margin-bottom: 8px;">
              <strong>Risk Level:</strong> <span style="color: ${color}; font-weight: bold;">${riskLevel}</span>
            </p>
            <p style="font-size: 11px; color: #666;">
              Data from NASA FIRMS
            </p>
          </div>
        `;

        marker.bindPopup(popupContent);

        if (markerClusterGroupRef.current) {
          markerClusterGroupRef.current.addLayer(marker);
        } else {
          marker.addTo(mapInstanceRef.current);
        }
        
        markersRef.current.push(marker);
      });
    }

    // Add cyclone markers
    if (activeFilters.cyclones) {
      cyclones.forEach(cyclone => {
        const color = cyclone.windSpeed > 130 ? '#FF4444' : cyclone.windSpeed > 100 ? '#FF8C42' : '#FFD93D';
        
        const marker = L.circleMarker([cyclone.latitude, cyclone.longitude], {
          radius: 12,
          fillColor: color,
          color: '#fff',
          weight: 3,
          opacity: 1,
          fillOpacity: 0.6,
        });

        const popupContent = `
          <div style="color: #000; min-width: 200px;">
            <h3 style="font-weight: bold; margin-bottom: 8px; color: ${color};">
              🌀 Cyclone: ${cyclone.name}
            </h3>
            <p style="font-size: 12px; margin-bottom: 4px;">
              <strong>Wind Speed:</strong> ${cyclone.windSpeed} km/h
            </p>
            <p style="font-size: 12px; margin-bottom: 4px;">
              <strong>Category:</strong> ${cyclone.category}
            </p>
            <p style="font-size: 12px; margin-bottom: 4px;">
              <strong>Pressure:</strong> ${cyclone.pressure} mb
            </p>
            <p style="font-size: 12px; margin-bottom: 4px;">
              <strong>Status:</strong> ${cyclone.status}
            </p>
            <p style="font-size: 12px; margin-bottom: 8px;">
              <strong>Time:</strong> ${new Date(cyclone.time).toLocaleString()}
            </p>
            <p style="font-size: 11px; color: #666;">
              Data from GDACS
            </p>
          </div>
        `;

        marker.bindPopup(popupContent);

        if (markerClusterGroupRef.current) {
          markerClusterGroupRef.current.addLayer(marker);
        } else {
          marker.addTo(mapInstanceRef.current);
        }
        
        markersRef.current.push(marker);
      });
    }
  }, [earthquakes, wildfires, cyclones, activeFilters]);

  // Initial data load
  useEffect(() => {
    loadDisasterData();
    
    // Auto-refresh every 5 minutes
    const interval = setInterval(loadDisasterData, 5 * 60 * 1000);
    
    return () => clearInterval(interval);
  }, []);

  return (
    <Card className="glass-card">
      <CardContent className="p-4">
        <div className="flex flex-col gap-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <MapPin className="h-5 w-5 text-primary" />
              <h3 className="font-semibold">Real-Time Disaster Map</h3>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-xs text-muted-foreground">
                Updated: {lastUpdate.toLocaleTimeString()}
              </span>
              <Button
                variant="outline"
                size="sm"
                onClick={loadDisasterData}
                disabled={loading}
              >
                {loading && loadingType === 'all' ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <RefreshCw className="h-4 w-4" />
                )}
              </Button>
            </div>
          </div>

          <div className="flex flex-wrap gap-2">
            <Badge 
              variant={activeFilters.earthquakes ? "default" : "outline"} 
              className="gap-1 cursor-pointer"
              onClick={() => setActiveFilters(prev => ({ ...prev, earthquakes: !prev.earthquakes }))}
            >
              <span className="w-2 h-2 rounded-full bg-[#FF4444]"></span>
              Earthquakes: {stats.earthquakes}
            </Badge>
            <Badge 
              variant={activeFilters.wildfires ? "default" : "outline"} 
              className="gap-1 cursor-pointer"
              onClick={() => setActiveFilters(prev => ({ ...prev, wildfires: !prev.wildfires }))}
            >
              <span className="w-2 h-2 rounded-full bg-[#FF8C42]"></span>
              Wildfires: {stats.wildfires}
            </Badge>
            <Badge 
              variant={activeFilters.cyclones ? "default" : "outline"} 
              className="gap-1 cursor-pointer"
              onClick={() => setActiveFilters(prev => ({ ...prev, cyclones: !prev.cyclones }))}
            >
              <span className="w-2 h-2 rounded-full bg-[#FFD93D]"></span>
              Cyclones: {stats.cyclones}
            </Badge>
            <Badge variant="destructive" className="gap-1">
              Critical: {stats.critical}
            </Badge>
          </div>

          <div className="flex flex-wrap gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => loadSpecificData('earthquakes')}
              disabled={loadingType === 'earthquakes'}
              className="gap-2"
            >
              {loadingType === 'earthquakes' ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <Activity className="h-4 w-4" />
              )}
              Load Earthquakes
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => loadSpecificData('wildfires')}
              disabled={loadingType === 'wildfires'}
              className="gap-2"
            >
              {loadingType === 'wildfires' ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <Flame className="h-4 w-4" />
              )}
              Load Wildfires
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => loadSpecificData('cyclones')}
              disabled={loadingType === 'cyclones'}
              className="gap-2"
            >
              {loadingType === 'cyclones' ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <Wind className="h-4 w-4" />
              )}
              Load Cyclones
            </Button>
          </div>

          <div 
            ref={mapRef} 
            className="w-full h-[500px] rounded-lg border border-border relative"
            style={{ background: '#0A1929' }}
          >
            {loading && loadingType === 'all' && (
              <div className="absolute inset-0 flex items-center justify-center bg-background/80 backdrop-blur z-[1000]">
                <div className="text-center">
                  <Loader2 className="h-8 w-8 animate-spin text-primary mx-auto mb-2" />
                  <p className="text-sm text-muted-foreground">Loading real-time data...</p>
                </div>
              </div>
            )}
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-xs">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-[#00FF88]"></div>
              <span>Low (M &lt; 4)</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-[#FFD93D]"></div>
              <span>Moderate (M 4-5.5)</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-[#FF8C42]"></div>
              <span>High (M 5.5-7)</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-[#FF4444]"></div>
              <span>Critical (M ≥ 7)</span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
