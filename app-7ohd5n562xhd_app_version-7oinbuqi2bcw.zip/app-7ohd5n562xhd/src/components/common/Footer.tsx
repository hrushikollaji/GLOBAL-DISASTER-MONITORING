import { AlertTriangle, Mail, Phone, MapPin } from "lucide-react";
import { Link } from "react-router-dom";

const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="glass-card border-t border-primary/20 mt-auto">
      <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="p-2 rounded-lg bg-primary/10">
                <AlertTriangle className="h-5 w-5 text-primary" />
              </div>
              <span className="text-lg font-bold gradient-text">
                AI Disaster Alert
              </span>
            </div>
            <p className="text-muted-foreground text-sm">
              Real-time disaster monitoring and AI-powered early warning system for global safety.
            </p>
          </div>

          <div>
            <h3 className="text-lg font-semibold text-foreground mb-4">
              Quick Links
            </h3>
            <div className="space-y-2">
              <Link to="/" className="block text-muted-foreground hover:text-primary transition-smooth text-sm">
                Home
              </Link>
              <Link to="/analytics" className="block text-muted-foreground hover:text-primary transition-smooth text-sm">
                Analytics
              </Link>
              <Link to="/alerts" className="block text-muted-foreground hover:text-primary transition-smooth text-sm">
                Alerts
              </Link>
              <Link to="/resources" className="block text-muted-foreground hover:text-primary transition-smooth text-sm">
                Resources
              </Link>
            </div>
          </div>

          <div>
            <h3 className="text-lg font-semibold text-foreground mb-4">
              Emergency
            </h3>
            <div className="space-y-3">
              <div className="flex items-center gap-2 text-muted-foreground text-sm">
                <Phone className="h-4 w-4 text-primary" />
                <span>Emergency: 911</span>
              </div>
              <div className="flex items-center gap-2 text-muted-foreground text-sm">
                <Mail className="h-4 w-4 text-primary" />
                <span>alert@disaster.ai</span>
              </div>
              <div className="flex items-center gap-2 text-muted-foreground text-sm">
                <MapPin className="h-4 w-4 text-primary" />
                <span>Global Coverage</span>
              </div>
            </div>
          </div>

          <div>
            <h3 className="text-lg font-semibold text-foreground mb-4">
              Data Sources
            </h3>
            <div className="space-y-2 text-sm text-muted-foreground">
              <p>USGS - Earthquakes</p>
              <p>NASA FIRMS - Wildfires</p>
              <p>NOAA - Weather & Tsunami</p>
              <p>GDACS - Multi-hazard</p>
            </div>
          </div>
        </div>

        <div className="mt-8 pt-8 border-t border-border text-center">
          <p className="text-muted-foreground text-sm">
            {currentYear} AI Disaster Alert Platform
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
