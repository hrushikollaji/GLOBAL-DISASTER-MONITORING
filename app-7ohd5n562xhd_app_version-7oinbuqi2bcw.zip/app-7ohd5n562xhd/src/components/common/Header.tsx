import { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import { Menu, X, AlertTriangle, User, LogOut, Bell } from "lucide-react";
import routes from "../../routes";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { storage } from "@/lib/storage";

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [user, setUser] = useState(storage.getUser());
  const [unreadAlerts, setUnreadAlerts] = useState(0);
  const location = useLocation();
  const navigation = routes.filter((route) => route.visible !== false && route.path !== '*');

  useEffect(() => {
    const handleStorageChange = () => {
      setUser(storage.getUser());
    };
    
    const checkAlerts = () => {
      const alerts = storage.getAlerts();
      const unread = alerts.filter(a => !a.isRead).length;
      setUnreadAlerts(unread);
    };

    checkAlerts();
    window.addEventListener('storage', handleStorageChange);
    window.addEventListener('storage', checkAlerts);
    
    const interval = setInterval(checkAlerts, 2000);

    return () => {
      window.removeEventListener('storage', handleStorageChange);
      window.removeEventListener('storage', checkAlerts);
      clearInterval(interval);
    };
  }, []);

  const handleLogout = () => {
    storage.setUser(null);
    setUser(null);
    setIsMenuOpen(false);
    window.location.href = '/login';
  };

  return (
    <header className="glass-card sticky top-0 z-50 border-b border-primary/20">
      <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center gap-2 sm:gap-3">
            <Link to="/" className="flex items-center gap-2 group" onClick={() => setIsMenuOpen(false)}>
              <div className="p-1.5 sm:p-2 rounded-lg bg-primary/10 group-hover:bg-primary/20 transition-smooth animate-pulse-glow">
                <AlertTriangle className="h-5 w-5 sm:h-6 sm:w-6 text-primary" />
              </div>
              <div className="flex flex-col">
                <span className="text-base sm:text-xl font-bold gradient-text">
                  AI Disaster Alert
                </span>
                <span className="text-[10px] text-muted-foreground hidden sm:block">
                  Real-time Monitoring
                </span>
              </div>
            </Link>
          </div>

          <div className="hidden xl:flex items-center gap-1">
            {navigation.map((item) => {
              const isAlerts = item.path === '/alerts';
              return (
                <Link
                  key={item.path}
                  to={item.path}
                  className={`relative px-3 py-2 text-sm font-medium rounded-lg transition-smooth ${
                    location.pathname === item.path
                      ? "bg-primary/20 text-primary glow-border"
                      : "text-foreground/80 hover:text-primary hover:bg-primary/10"
                  }`}
                >
                  {item.name}
                  {isAlerts && unreadAlerts > 0 && (
                    <Badge 
                      variant="destructive" 
                      className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center p-0 text-[10px] animate-pulse"
                    >
                      {unreadAlerts > 9 ? '9+' : unreadAlerts}
                    </Badge>
                  )}
                </Link>
              );
            })}
          </div>

          <div className="flex items-center gap-2">
            <Link to="/alerts" className="xl:hidden relative">
              <Button variant="ghost" size="icon" className="relative">
                <Bell className="h-5 w-5" />
                {unreadAlerts > 0 && (
                  <Badge 
                    variant="destructive" 
                    className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center p-0 text-[10px] animate-pulse"
                  >
                    {unreadAlerts > 9 ? '9+' : unreadAlerts}
                  </Badge>
                )}
              </Button>
            </Link>

            <div className="hidden xl:flex items-center gap-2">
              {user ? (
                <>
                  <Link to="/profile">
                    <Button variant="ghost" size="sm" className="gap-2">
                      <User className="h-4 w-4" />
                      <span className="max-w-[100px] truncate">{user.name}</span>
                    </Button>
                  </Link>
                  {user.role === 'admin' && (
                    <Link to="/admin">
                      <Button variant="outline" size="sm" className="gap-2 border-primary/30">
                        <AlertTriangle className="h-4 w-4 text-primary" />
                        <span className="text-primary">Admin</span>
                      </Button>
                    </Link>
                  )}
                  <Button variant="ghost" size="icon" onClick={handleLogout} title="Logout">
                    <LogOut className="h-4 w-4" />
                  </Button>
                </>
              ) : (
                <Link to="/login">
                  <Button variant="default" size="sm">
                    Login
                  </Button>
                </Link>
              )}
            </div>

            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="xl:hidden p-2 rounded-lg hover:bg-primary/10 transition-smooth"
              aria-label="Toggle menu"
            >
              {isMenuOpen ? (
                <X className="h-6 w-6 text-foreground" />
              ) : (
                <Menu className="h-6 w-6 text-foreground" />
              )}
            </button>
          </div>
        </div>

        {isMenuOpen && (
          <div className="xl:hidden py-4 space-y-1 animate-in slide-in-from-top-2 duration-200">
            {navigation.map((item) => {
              const isAlerts = item.path === '/alerts';
              return (
                <Link
                  key={item.path}
                  to={item.path}
                  onClick={() => setIsMenuOpen(false)}
                  className={`flex items-center justify-between px-4 py-3 text-sm font-medium rounded-lg transition-smooth ${
                    location.pathname === item.path
                      ? "bg-primary/20 text-primary"
                      : "text-foreground/80 hover:text-primary hover:bg-primary/10"
                  }`}
                >
                  <span>{item.name}</span>
                  {isAlerts && unreadAlerts > 0 && (
                    <Badge variant="destructive" className="animate-pulse">
                      {unreadAlerts} new
                    </Badge>
                  )}
                </Link>
              );
            })}
            
            <div className="pt-3 mt-3 border-t border-border space-y-1">
              {user ? (
                <>
                  <Link
                    to="/profile"
                    onClick={() => setIsMenuOpen(false)}
                    className="flex items-center gap-2 px-4 py-3 text-sm font-medium rounded-lg text-foreground/80 hover:text-primary hover:bg-primary/10 transition-smooth"
                  >
                    <User className="h-4 w-4" />
                    <span className="truncate">{user.name}</span>
                  </Link>
                  {user.role === 'admin' && (
                    <Link
                      to="/admin"
                      onClick={() => setIsMenuOpen(false)}
                      className="flex items-center gap-2 px-4 py-3 text-sm font-medium rounded-lg text-primary hover:bg-primary/10 transition-smooth"
                    >
                      <AlertTriangle className="h-4 w-4" />
                      Admin Dashboard
                    </Link>
                  )}
                  <button
                    onClick={handleLogout}
                    className="w-full flex items-center gap-2 px-4 py-3 text-sm font-medium rounded-lg text-foreground/80 hover:text-primary hover:bg-primary/10 transition-smooth"
                  >
                    <LogOut className="h-4 w-4" />
                    Logout
                  </button>
                </>
              ) : (
                <Link
                  to="/login"
                  onClick={() => setIsMenuOpen(false)}
                  className="block px-4 py-3 text-sm font-medium rounded-lg bg-primary text-primary-foreground hover:bg-primary/90 transition-smooth text-center"
                >
                  Login
                </Link>
              )}
            </div>
          </div>
        )}
      </nav>
    </header>
  );
};

export default Header;
