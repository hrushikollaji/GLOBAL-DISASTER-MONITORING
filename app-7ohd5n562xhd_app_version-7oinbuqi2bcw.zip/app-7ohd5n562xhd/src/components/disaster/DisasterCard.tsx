import { MapPin, Clock, AlertCircle, ExternalLink, Bookmark } from "lucide-react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import type { DisasterEvent } from "@/types";
import { disasterLabels, severityLabels, formatTimestamp, getSeverityColor } from "@/lib/disasterUtils";
import { storage } from "@/lib/storage";
import { useState } from "react";

interface DisasterCardProps {
  disaster: DisasterEvent;
  onViewDetails?: (disaster: DisasterEvent) => void;
}

export function DisasterCard({ disaster, onViewDetails }: DisasterCardProps) {
  const [isBookmarked, setIsBookmarked] = useState(
    storage.getBookmarks().includes(disaster.id)
  );

  const handleBookmark = (e: React.MouseEvent) => {
    e.stopPropagation();
    const bookmarked = storage.toggleBookmark(disaster.id);
    setIsBookmarked(bookmarked);
  };

  const severityColor = getSeverityColor(disaster.severity);

  return (
    <Card 
      className="glass-card hover:glow-border transition-smooth cursor-pointer group"
      onClick={() => onViewDetails?.(disaster)}
    >
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between gap-2">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-2">
              <Badge 
                variant="outline" 
                className="text-xs"
                style={{ borderColor: severityColor, color: severityColor }}
              >
                {disasterLabels[disaster.type]}
              </Badge>
              <Badge 
                variant="outline" 
                className="text-xs font-semibold"
                style={{ 
                  borderColor: severityColor, 
                  color: severityColor,
                  backgroundColor: `${severityColor}15`
                }}
              >
                {severityLabels[disaster.severity]}
              </Badge>
            </div>
            <h3 className="text-lg font-semibold text-foreground group-hover:text-primary transition-smooth">
              {disaster.title}
            </h3>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={handleBookmark}
            className="shrink-0"
          >
            <Bookmark 
              className={`h-4 w-4 ${isBookmarked ? 'fill-primary text-primary' : 'text-muted-foreground'}`}
            />
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        <p className="text-sm text-muted-foreground line-clamp-2">
          {disaster.description}
        </p>
        
        <div className="space-y-2">
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <MapPin className="h-3 w-3 text-primary" />
            <span>{disaster.location.address}</span>
          </div>
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <Clock className="h-3 w-3 text-primary" />
            <span>{formatTimestamp(disaster.timestamp)}</span>
          </div>
          {disaster.magnitude && (
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <AlertCircle className="h-3 w-3 text-primary" />
              <span>Magnitude: {disaster.magnitude}</span>
            </div>
          )}
        </div>

        <div className="flex items-center justify-between pt-2">
          <span className="text-xs text-muted-foreground">
            Source: {disaster.source}
          </span>
          {disaster.externalLink && (
            <Button
              variant="ghost"
              size="sm"
              className="h-7 text-xs gap-1"
              onClick={(e) => {
                e.stopPropagation();
                window.open(disaster.externalLink, '_blank');
              }}
            >
              <ExternalLink className="h-3 w-3" />
              Details
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
}