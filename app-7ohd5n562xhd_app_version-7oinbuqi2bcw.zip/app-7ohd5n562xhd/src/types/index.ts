export interface Option {
  label: string;
  value: string;
  icon?: React.ComponentType<{ className?: string }>;
  withCount?: boolean;
}

export type DisasterType = 'earthquake' | 'flood' | 'cyclone' | 'tsunami' | 'landslide' | 'wildfire';

export type SeverityLevel = 'low' | 'moderate' | 'high' | 'critical';

export interface DisasterEvent {
  id: string;
  type: DisasterType;
  title: string;
  description: string;
  location: {
    lat: number;
    lng: number;
    address: string;
    country: string;
  };
  severity: SeverityLevel;
  magnitude?: number;
  timestamp: string;
  affectedArea?: number;
  casualties?: number;
  status: 'active' | 'monitoring' | 'resolved';
  source: string;
  externalLink?: string;
}

export interface Alert {
  id: string;
  disasterId: string;
  type: DisasterType;
  severity: SeverityLevel;
  title: string;
  message: string;
  location: string;
  timestamp: string;
  isRead: boolean;
  channels: ('email' | 'sms' | 'push')[];
}

export interface CitizenReport {
  id: string;
  type: DisasterType;
  location: {
    lat: number;
    lng: number;
    address: string;
  };
  description: string;
  photos: string[];
  reporterName?: string;
  reporterContact?: string;
  timestamp: string;
  status: 'pending' | 'verified' | 'rejected';
  verifiedBy?: string;
}

export interface EmergencyShelter {
  id: string;
  name: string;
  location: {
    lat: number;
    lng: number;
    address: string;
  };
  capacity: number;
  currentOccupancy: number;
  amenities: string[];
  contact: string;
  isOpen: boolean;
}

export interface UserPreferences {
  userId: string;
  alertTypes: DisasterType[];
  notificationChannels: ('email' | 'sms' | 'push')[];
  savedLocations: {
    name: string;
    lat: number;
    lng: number;
  }[];
  language: string;
}

export interface User {
  id: string;
  email: string;
  name: string;
  role: 'user' | 'admin';
  createdAt: string;
}

export interface PredictionData {
  type: DisasterType;
  location: {
    lat: number;
    lng: number;
    region: string;
  };
  probability: number;
  confidence: number;
  timeframe: string;
  factors: string[];
}
