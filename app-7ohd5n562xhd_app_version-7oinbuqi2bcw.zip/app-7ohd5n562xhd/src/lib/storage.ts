import type { User, UserPreferences, Alert, CitizenReport, DisasterEvent } from '@/types';

const STORAGE_KEYS = {
  USER: 'disaster_user',
  PREFERENCES: 'disaster_preferences',
  ALERTS: 'disaster_alerts',
  REPORTS: 'disaster_reports',
  BOOKMARKS: 'disaster_bookmarks',
  DISASTERS: 'disaster_events',
} as const;

export const storage = {
  getUser: (): User | null => {
    const data = localStorage.getItem(STORAGE_KEYS.USER);
    return data ? JSON.parse(data) : null;
  },

  setUser: (user: User | null) => {
    if (user) {
      localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(user));
    } else {
      localStorage.removeItem(STORAGE_KEYS.USER);
    }
  },

  getPreferences: (): UserPreferences | null => {
    const data = localStorage.getItem(STORAGE_KEYS.PREFERENCES);
    return data ? JSON.parse(data) : null;
  },

  setPreferences: (preferences: UserPreferences) => {
    localStorage.setItem(STORAGE_KEYS.PREFERENCES, JSON.stringify(preferences));
  },

  getAlerts: (): Alert[] => {
    const data = localStorage.getItem(STORAGE_KEYS.ALERTS);
    return data ? JSON.parse(data) : [];
  },

  setAlerts: (alerts: Alert[]) => {
    localStorage.setItem(STORAGE_KEYS.ALERTS, JSON.stringify(alerts));
  },

  addAlert: (alert: Alert) => {
    const alerts = storage.getAlerts();
    alerts.unshift(alert);
    storage.setAlerts(alerts);
  },

  getReports: (): CitizenReport[] => {
    const data = localStorage.getItem(STORAGE_KEYS.REPORTS);
    return data ? JSON.parse(data) : [];
  },

  setReports: (reports: CitizenReport[]) => {
    localStorage.setItem(STORAGE_KEYS.REPORTS, JSON.stringify(reports));
  },

  addReport: (report: CitizenReport) => {
    const reports = storage.getReports();
    reports.unshift(report);
    storage.setReports(reports);
  },

  getBookmarks: (): string[] => {
    const data = localStorage.getItem(STORAGE_KEYS.BOOKMARKS);
    return data ? JSON.parse(data) : [];
  },

  setBookmarks: (bookmarks: string[]) => {
    localStorage.setItem(STORAGE_KEYS.BOOKMARKS, JSON.stringify(bookmarks));
  },

  toggleBookmark: (disasterId: string) => {
    const bookmarks = storage.getBookmarks();
    const index = bookmarks.indexOf(disasterId);
    if (index > -1) {
      bookmarks.splice(index, 1);
    } else {
      bookmarks.push(disasterId);
    }
    storage.setBookmarks(bookmarks);
    return index === -1;
  },

  getDisasters: (): DisasterEvent[] => {
    const data = localStorage.getItem(STORAGE_KEYS.DISASTERS);
    return data ? JSON.parse(data) : [];
  },

  setDisasters: (disasters: DisasterEvent[]) => {
    localStorage.setItem(STORAGE_KEYS.DISASTERS, JSON.stringify(disasters));
  },

  clear: () => {
    Object.values(STORAGE_KEYS).forEach(key => {
      localStorage.removeItem(key);
    });
  },
};
