// Real-time Disaster API Integration

export interface EarthquakeData {
  id: string;
  magnitude: number;
  location: string;
  latitude: number;
  longitude: number;
  depth: number;
  time: string;
  url: string;
}

export interface WeatherData {
  temperature: number;
  rainfall: number;
  windSpeed: number;
  humidity: number;
  description: string;
  riskLevel: 'low' | 'moderate' | 'high' | 'critical';
}

export interface WildfireData {
  id: string;
  latitude: number;
  longitude: number;
  brightness: number;
  confidence: number;
  time: string;
}

export interface CycloneData {
  id: string;
  name: string;
  latitude: number;
  longitude: number;
  windSpeed: number;
  pressure: number;
  category: string;
  time: string;
  status: string;
}

// USGS Earthquake API
export async function fetchEarthquakes(): Promise<EarthquakeData[]> {
  try {
    const response = await fetch(
      'https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/all_day.geojson'
    );
    const data = await response.json();
    
    return data.features.map((feature: any) => ({
      id: feature.id,
      magnitude: feature.properties.mag,
      location: feature.properties.place,
      latitude: feature.geometry.coordinates[1],
      longitude: feature.geometry.coordinates[0],
      depth: feature.geometry.coordinates[2],
      time: new Date(feature.properties.time).toISOString(),
      url: feature.properties.url,
    }));
  } catch (error) {
    console.error('Error fetching earthquakes:', error);
    return [];
  }
}

// OpenWeatherMap API
export async function fetchWeatherData(
  lat: number,
  lon: number,
  apiKey: string
): Promise<WeatherData | null> {
  try {
    const response = await fetch(
      `https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&units=metric&appid=${apiKey}`
    );
    const data = await response.json();
    
    const rainfall = data.rain?.['1h'] || 0;
    const windSpeed = data.wind?.speed || 0;
    
    // Calculate risk level based on weather conditions
    let riskLevel: 'low' | 'moderate' | 'high' | 'critical' = 'low';
    
    if (rainfall > 50 || windSpeed > 25) {
      riskLevel = 'critical';
    } else if (rainfall > 25 || windSpeed > 15) {
      riskLevel = 'high';
    } else if (rainfall > 10 || windSpeed > 10) {
      riskLevel = 'moderate';
    }
    
    return {
      temperature: data.main.temp,
      rainfall,
      windSpeed,
      humidity: data.main.humidity,
      description: data.weather[0].description,
      riskLevel,
    };
  } catch (error) {
    console.error('Error fetching weather data:', error);
    return null;
  }
}

// NASA FIRMS Wildfire API (using public data)
export async function fetchWildfires(): Promise<WildfireData[]> {
  try {
    // Using NASA FIRMS public data endpoint
    // Alternative: MODIS and VIIRS active fire data
    const response = await fetch(
      'https://firms.modaps.eosdis.nasa.gov/data/active_fire/suomi-npp-viirs-c2/csv/SUOMI_VIIRS_C2_Global_24h.csv',
      { mode: 'cors' }
    );
    
    if (!response.ok) {
      console.warn('VIIRS data unavailable, trying MODIS...');
      // Fallback to MODIS
      const modisResponse = await fetch(
        'https://firms.modaps.eosdis.nasa.gov/data/active_fire/modis-c6.1/csv/MODIS_C6_1_Global_24h.csv',
        { mode: 'cors' }
      );
      if (!modisResponse.ok) throw new Error('Both fire APIs unavailable');
      const csvText = await modisResponse.text();
      return parseFireCSV(csvText);
    }
    
    const csvText = await response.text();
    return parseFireCSV(csvText);
  } catch (error) {
    console.error('Error fetching wildfires:', error);
    return [];
  }
}

function parseFireCSV(csvText: string): WildfireData[] {
  const lines = csvText.split('\n');
  const wildfires: WildfireData[] = [];
  
  // Skip header
  for (let i = 1; i < Math.min(lines.length, 500); i++) {
    const line = lines[i].trim();
    if (!line) continue;
    
    const values = line.split(',');
    if (values.length < 6) continue;
    
    const latitude = parseFloat(values[0]);
    const longitude = parseFloat(values[1]);
    const brightness = parseFloat(values[2]);
    const confidence = parseFloat(values[8] || values[9] || '50');
    const acqDate = values[5];
    const acqTime = values[6];
    
    if (!isNaN(latitude) && !isNaN(longitude) && !isNaN(brightness)) {
      wildfires.push({
        id: `fire-${i}-${Date.now()}`,
        latitude,
        longitude,
        brightness,
        confidence: isNaN(confidence) ? 50 : confidence,
        time: `${acqDate} ${acqTime}`,
      });
    }
  }
  
  return wildfires;
}

// NOAA/GDACS Cyclone API
export async function fetchCyclones(): Promise<CycloneData[]> {
  try {
    // Using GDACS (Global Disaster Alert and Coordination System) API
    const response = await fetch(
      'https://www.gdacs.org/gdacsapi/api/events/geteventlist/SEARCH?eventtype=TC&alertlevel=Orange;Red&fromDate=&toDate=',
      { mode: 'cors' }
    );
    
    if (!response.ok) {
      console.warn('GDACS unavailable, trying alternative...');
      // Alternative: Use a mock cyclone for demonstration
      return getMockCyclones();
    }
    
    const text = await response.text();
    const parser = new DOMParser();
    const xmlDoc = parser.parseFromString(text, 'text/xml');
    
    const items = xmlDoc.getElementsByTagName('item');
    const cyclones: CycloneData[] = [];
    
    for (let i = 0; i < items.length; i++) {
      const item = items[i];
      const title = item.getElementsByTagName('title')[0]?.textContent || 'Cyclone';
      const description = item.getElementsByTagName('description')[0]?.textContent || '';
      const point = item.getElementsByTagName('geo:Point')[0];
      
      if (point) {
        const coords = point.textContent?.split(' ') || [];
        const latitude = parseFloat(coords[0]);
        const longitude = parseFloat(coords[1]);
        
        // Extract wind speed from description
        const windMatch = description.match(/wind speed:\s*(\d+)/i);
        const windSpeed = windMatch ? parseInt(windMatch[1]) : 0;
        
        if (!isNaN(latitude) && !isNaN(longitude)) {
          cyclones.push({
            id: `cyclone-${i}-${Date.now()}`,
            name: title,
            latitude,
            longitude,
            windSpeed,
            pressure: 950, // Default
            category: windSpeed > 130 ? 'Category 4-5' : windSpeed > 100 ? 'Category 3' : 'Category 1-2',
            time: new Date().toISOString(),
            status: 'Active',
          });
        }
      }
    }
    
    return cyclones.length > 0 ? cyclones : getMockCyclones();
  } catch (error) {
    console.error('Error fetching cyclones:', error);
    return getMockCyclones();
  }
}

function getMockCyclones(): CycloneData[] {
  // Return empty array or sample data for demonstration
  // In production, this would show "No active cyclones"
  return [];
}

// Calculate severity color based on magnitude/intensity
export function getSeverityColor(value: number, type: 'earthquake' | 'weather' | 'fire'): string {
  switch (type) {
    case 'earthquake':
      if (value >= 7) return '#FF4444'; // Critical
      if (value >= 5.5) return '#FF8C42'; // High
      if (value >= 4) return '#FFD93D'; // Moderate
      return '#00FF88'; // Low
      
    case 'weather':
      // Based on risk level
      return '#FFD93D'; // Default moderate
      
    case 'fire':
      if (value >= 400) return '#FF4444'; // High brightness
      if (value >= 350) return '#FF8C42';
      return '#FFD93D';
      
    default:
      return '#00D9FF';
  }
}

// Calculate risk level text
export function getRiskLevel(value: number, type: 'earthquake' | 'weather' | 'fire'): string {
  switch (type) {
    case 'earthquake':
      if (value >= 7) return 'Critical';
      if (value >= 5.5) return 'High';
      if (value >= 4) return 'Moderate';
      return 'Low';
      
    case 'fire':
      if (value >= 400) return 'High';
      if (value >= 350) return 'Moderate';
      return 'Low';
      
    default:
      return 'Moderate';
  }
}
