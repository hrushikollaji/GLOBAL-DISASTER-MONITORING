import type { DisasterType, SeverityLevel } from '@/types';

export const disasterColors: Record<DisasterType, string> = {
  earthquake: '#FF6B6B',
  flood: '#4ECDC4',
  cyclone: '#95E1D3',
  tsunami: '#38A3A5',
  landslide: '#C7B198',
  wildfire: '#FF8C42',
};

export const severityColors: Record<SeverityLevel, string> = {
  low: '#00FF88',
  moderate: '#FFD93D',
  high: '#FF8C42',
  critical: '#FF4444',
};

export const disasterIcons: Record<DisasterType, string> = {
  earthquake: '🌍',
  flood: '🌊',
  cyclone: '🌀',
  tsunami: '🌊',
  landslide: '⛰️',
  wildfire: '🔥',
};

export const disasterLabels: Record<DisasterType, string> = {
  earthquake: 'Earthquake',
  flood: 'Flood',
  cyclone: 'Cyclone',
  tsunami: 'Tsunami',
  landslide: 'Landslide',
  wildfire: 'Wildfire',
};

export const severityLabels: Record<SeverityLevel, string> = {
  low: 'Low',
  moderate: 'Moderate',
  high: 'High',
  critical: 'Critical',
};

export function getSeverityColor(severity: SeverityLevel): string {
  return severityColors[severity];
}

export function getDisasterColor(type: DisasterType): string {
  return disasterColors[type];
}

export function formatTimestamp(timestamp: string): string {
  const date = new Date(timestamp);
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  const diffMins = Math.floor(diffMs / 60000);
  const diffHours = Math.floor(diffMs / 3600000);
  const diffDays = Math.floor(diffMs / 86400000);

  if (diffMins < 1) return 'Just now';
  if (diffMins < 60) return `${diffMins}m ago`;
  if (diffHours < 24) return `${diffHours}h ago`;
  if (diffDays < 7) return `${diffDays}d ago`;
  
  return date.toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: date.getFullYear() !== now.getFullYear() ? 'numeric' : undefined,
  });
}

export function generateDisasterId(): string {
  return `disaster_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
}

export function generateAlertId(): string {
  return `alert_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
}

export function generateReportId(): string {
  return `report_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
}
